#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Gravar Doc — ajuste direto no OBS: 4 pistas de áudio no arquivo gravado
#   1 = mix   2 = fonte (WhatsApp/Chrome/sistema, conforme a cena)   3 = microfone   4 = áudio do sistema
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
# Uso: feche o OBS, rode  python3 obs_4pistas.py , abra o OBS de novo.
#      Rodar DEPOIS do "1 Preparar" (o Preparar reescreve os arquivos e desfaz o ajuste).
import json, re, sys, uuid, shutil, subprocess
from pathlib import Path

OBS = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / "Library/Application Support/obs-studio"
PROFILE = OBS / "basic/profiles/Untitled/basic.ini"
SCENES = OBS / "basic/scenes/Untitled.json"
NOME = "Audio do sistema (pista 4)"
MIXERS = 1 | 8                       # pistas 1 e 4

def die(m): print("ERRO:", m); sys.exit(1)

if subprocess.run(["pgrep", "-x", "OBS"], capture_output=True).returncode == 0:
    die("feche o OBS antes de rodar este script.")
for f in (PROFILE, SCENES):
    if not f.exists(): die(f"não encontrei {f} — rode o '1 Preparar' primeiro.")
    shutil.copy2(f, f.with_suffix(f.suffix + ".bak"))

# 1. perfil: gravar 4 pistas
ini = PROFILE.read_text(encoding="utf-8")
ini = re.sub(r"(?m)^RecTracks=.*$", "RecTracks=15", ini)
if "Track4Bitrate" not in ini:
    ini = ini.replace("Track3Bitrate=320", "Track3Bitrate=320\nTrack4Bitrate=320")
PROFILE.write_text(ini, encoding="utf-8")

# 2. cenas: uma fonte de áudio do sistema compartilhada, em todas as cenas, só nas pistas 1 e 4
doc = json.loads(SCENES.read_text(encoding="utf-8"))
src = next((s for s in doc["sources"] if s["name"] == NOME), None)
if src is None:
    modelo = next(s for s in doc["sources"] if s["id"] == "sck_audio_capture")
    src = json.loads(json.dumps(modelo))
    src.update({"name": NOME, "uuid": str(uuid.uuid4()), "settings": {"type": 0}, "mixers": MIXERS})
    doc["sources"].append(src)
src["mixers"] = MIXERS
for cena in (s for s in doc["sources"] if s["id"] == "scene"):
    itens = cena["settings"]["items"]
    if any(i.get("source_uuid") == src["uuid"] for i in itens): continue
    item = json.loads(json.dumps(itens[-1]))
    item.update({"name": NOME, "source_uuid": src["uuid"], "id": max(i["id"] for i in itens) + 1})
    itens.append(item); cena["settings"]["id_counter"] = item["id"]
SCENES.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
print("OK: OBS configurado para 4 pistas (1 mix, 2 fonte, 3 microfone, 4 sistema).")
print("Abra o OBS e confira em Configurações > Saída > Gravação: faixas 1-4 marcadas.")
