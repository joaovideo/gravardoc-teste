# -*- coding: utf-8 -*-
# Gravar Doc — tela de abertura (marca, copyright, licença e divulgação V-Engine / VENG)
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
from AppKit import (NSPanel, NSColor, NSFont, NSTextField, NSMakeRect, NSBackingStoreBuffered,
                    NSWindowStyleMaskBorderless, NSFloatingWindowLevel, NSTextAlignmentCenter, NSScreen, NSView)
from Foundation import NSTimer

W, H = 560, 380
VERMELHO = NSColor.colorWithCalibratedRed_green_blue_alpha_(0.898, 0.035, 0.078, 1)
TEXTO = NSColor.colorWithCalibratedWhite_alpha_(0.92, 1)
CINZA = NSColor.colorWithCalibratedWhite_alpha_(0.58, 1)

def _label(parent, texto, y, tam, cor, negrito=False, alt=None):
    f = NSTextField.alloc().initWithFrame_(NSMakeRect(24, y, W - 48, alt or tam * 1.6))
    f.setStringValue_(texto); f.setBezeled_(False); f.setDrawsBackground_(False); f.setEditable_(False); f.setSelectable_(False)
    f.setAlignment_(NSTextAlignmentCenter); f.setTextColor_(cor)
    f.setFont_(NSFont.boldSystemFontOfSize_(tam) if negrito else NSFont.systemFontOfSize_(tam))
    parent.addSubview_(f); return f

def mostrar(versao, licenca_txt, segundos=5.0):
    """Mostra a janela de abertura por alguns segundos (clique para fechar antes). Retorna o painel."""
    tela = NSScreen.mainScreen().frame()
    x = (tela.size.width - W) / 2; y = (tela.size.height - H) / 2 + 60
    p = NSPanel.alloc().initWithContentRect_styleMask_backing_defer_(NSMakeRect(x, y, W, H), NSWindowStyleMaskBorderless, NSBackingStoreBuffered, False)
    p.setLevel_(NSFloatingWindowLevel); p.setOpaque_(False); p.setHasShadow_(True)
    p.setBackgroundColor_(NSColor.colorWithCalibratedRed_green_blue_alpha_(0.051, 0.067, 0.09, 0.98))
    p.setMovableByWindowBackground_(True); p.setHidesOnDeactivate_(False)
    v = p.contentView()
    faixa = NSTextField.alloc().initWithFrame_(NSMakeRect(0, H - 6, W, 6))
    faixa.setBezeled_(False); faixa.setEditable_(False); faixa.setDrawsBackground_(True); faixa.setBackgroundColor_(VERMELHO); v.addSubview_(faixa)

    _label(v, "V-ENGINE", H - 70, 30, VERMELHO, True)
    _label(v, "divisão de desenvolvimento de software da VENG", H - 96, 12, CINZA)
    _label(v, f"Gravar Doc {versao}", H - 150, 24, TEXTO, True)
    _label(v, "Captura de tela e áudio a 23,976 fps · WhatsApp · Chrome · Tela inteira", H - 176, 12, CINZA)
    _label(v, licenca_txt, H - 214, 12, TEXTO)
    _label(v, "VENG Projetos e Tecnologia — engenharia de áudio, vídeo e broadcast\n"
              "Projetos AV · Transmissão ao vivo · Backup LTO · Treinamentos vMix e Resolume",
           92, 12, TEXTO, alt=40)
    _label(v, "video.eng.br  ·  contato@video.eng.br", 66, 12, VERMELHO, True)
    _label(v, "© 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.\n"
              "Software proprietário (Lei 9.609/1998). Uso somente mediante licença.",
           16, 10, CINZA, alt=34)
    p.orderFrontRegardless()
    NSTimer.scheduledTimerWithTimeInterval_repeats_block_(segundos, False, lambda t: p.orderOut_(None))
    return p
