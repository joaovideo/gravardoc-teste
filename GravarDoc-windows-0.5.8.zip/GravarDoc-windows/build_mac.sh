#!/bin/zsh
# Gera dist/Gravar Doc.app (compilado com Nuitka) e dist/GravarDoc-mac-<versão>.zip (nome SEMPRE com a versão)
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
set -e; cd "$(dirname "$0")"
VER=$(grep '^VERSAO' app_gravardoc.py | cut -d'"' -f2)
./venv/bin/pip -q install nuitka rumps pyobjc-framework-Quartz -r requirements.txt
./venv/bin/python -m nuitka --standalone --macos-create-app-bundle --macos-app-name="Gravar Doc" \
  --macos-app-mode=ui-element --macos-app-version=$VER --macos-signed-app-name=com.vengine.gravardoc \
  --product-name="Gravar Doc" --company-name="V-Engine / VENG Projetos e Tecnologia Ltda." \
  --copyright="© 2026 V-Engine / VENG. Todos os direitos reservados." \
  --include-module=gravar_doc --include-module=licenca --include-module=splash \
  --include-package=obsws_python --include-package=websocket --nofollow-import-to=nuitka \
  --output-dir=build --output-filename="Gravar Doc" --assume-yes-for-downloads app_gravardoc.py
rm -rf "dist/Gravar Doc.app"; mkdir -p dist; cp -R build/app_gravardoc.app "dist/Gravar Doc.app"
codesign --force --deep -s - "dist/Gravar Doc.app"
rm -f dist/GravarDoc-mac*.zip; ditto -c -k --keepParent "dist/Gravar Doc.app" "dist/GravarDoc-mac-$VER.zip"
echo "OK: dist/GravarDoc-mac-$VER.zip (Gravar Doc $VER)"
