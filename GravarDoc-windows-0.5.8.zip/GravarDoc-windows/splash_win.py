# -*- coding: utf-8 -*-
# Gravar Doc — tela de abertura Windows (marca, copyright, licença e divulgação V-Engine / VENG)
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
# Mesmo conteúdo e visual do splash.py (macOS), em tkinter.
import tkinter as tk

W, H = 560, 380
FUNDO = "#0d1117"; VERMELHO = "#e50914"; TEXTO = "#ebebeb"; CINZA = "#949494"
FONTE = "Segoe UI"

def mostrar(versao, licenca_txt, segundos=5.0, root=None):
    """Mostra a janela de abertura por alguns segundos (clique para fechar antes). Retorna a janela.
    Sem root, cria o próprio Tk e roda o loop (uso isolado/teste)."""
    proprio = root is None
    if proprio: root = tk.Tk(); root.withdraw()
    j = tk.Toplevel(root); j.overrideredirect(True); j.attributes("-topmost", True); j.configure(bg=FUNDO)
    sw, sh = j.winfo_screenwidth(), j.winfo_screenheight()
    j.geometry(f"{W}x{H}+{(sw - W) // 2}+{(sh - H) // 2 - 60}")
    tk.Frame(j, bg=VERMELHO, height=6).pack(fill="x", side="top")

    def lbl(texto, tam, cor, negrito=False, pady=0):
        tk.Label(j, text=texto, bg=FUNDO, fg=cor, font=(FONTE, tam, "bold" if negrito else "normal"),
                 justify="center").pack(pady=pady)

    lbl("V-ENGINE", 26, VERMELHO, True, (22, 0))
    lbl("divisão de desenvolvimento de software da VENG", 10, CINZA)
    lbl(f"Gravar Doc {versao}", 20, TEXTO, True, (22, 0))
    lbl("Captura de tela e áudio a 23,976 fps · WhatsApp · Chrome · Tela inteira", 10, CINZA)
    lbl(licenca_txt, 10, TEXTO, pady=(14, 0))
    rodape = tk.Frame(j, bg=FUNDO); rodape.pack(side="bottom", fill="x", pady=(0, 12))
    for texto, tam, cor, neg in (
            ("VENG Projetos e Tecnologia — engenharia de áudio, vídeo e broadcast\n"
             "Projetos AV · Transmissão ao vivo · Backup LTO · Treinamentos vMix e Resolume", 10, TEXTO, False),
            ("video.eng.br  ·  contato@video.eng.br", 10, VERMELHO, True),
            ("© 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.\n"
             "Software proprietário (Lei 9.609/1998). Uso somente mediante licença.", 8, CINZA, False)):
        tk.Label(rodape, text=texto, bg=FUNDO, fg=cor, font=(FONTE, tam, "bold" if neg else "normal"),
                 justify="center").pack(pady=(6, 0))

    def fechar(_=None):
        try: j.destroy()
        except tk.TclError: pass
        if proprio: root.quit()
    j.bind("<Button-1>", fechar)
    for w in j.winfo_children(): w.bind("<Button-1>", fechar)
    j.after(int(segundos * 1000), fechar)
    if proprio: root.mainloop()
    return j

def expirado(versao, motivo, id_maquina, root, importar):
    """Popup VENG quando a versão free venceu. importar() -> True se ativou uma licença.
    Bloqueia até fechar. Retorna True se o app pode seguir (licença importada)."""
    import webbrowser
    j = tk.Toplevel(root); j.title("Gravar Doc — versão free expirada"); j.configure(bg=FUNDO)
    j.attributes("-topmost", True); j.resizable(False, False)
    w, h = 600, 470; sw, sh = j.winfo_screenwidth(), j.winfo_screenheight()
    j.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2 - 40}")
    tk.Frame(j, bg=VERMELHO, height=6).pack(fill="x", side="top")
    res = {"ok": False}

    def lbl(texto, tam, cor, negrito=False, pady=0):
        tk.Label(j, text=texto, bg=FUNDO, fg=cor, font=(FONTE, tam, "bold" if negrito else "normal"),
                 justify="center", wraplength=w - 60).pack(pady=pady)

    lbl("V-ENGINE  ·  VENG", 22, VERMELHO, True, (18, 0))
    lbl(f"Gravar Doc {versao}", 16, TEXTO, True, (10, 0))
    lbl("O período de uso gratuito terminou.", 14, TEXTO, True, (16, 0))
    lbl(motivo, 10, CINZA, pady=(4, 0))
    lbl("Para continuar gravando, solicite a licença à VENG informando o ID desta máquina:", 10, TEXTO, pady=(14, 0))
    idl = tk.Entry(j, font=("Consolas", 11), justify="center", width=40, relief="flat",
                   readonlybackground="#161b22", fg=TEXTO, bd=6)
    idl.insert(0, id_maquina); idl.config(state="readonly"); idl.pack(pady=(6, 0))
    lbl("video.eng.br  ·  contato@video.eng.br", 11, VERMELHO, True, (12, 0))
    lbl("Projetos AV · Transmissão ao vivo · Backup LTO · Treinamentos vMix e Resolume", 9, CINZA, pady=(2, 0))

    bar = tk.Frame(j, bg=FUNDO); bar.pack(side="bottom", pady=16)
    def botao(txt, cmd, cor="#30363d"):
        tk.Button(bar, text=txt, command=cmd, font=(FONTE, 10, "bold"), fg="white", bg=cor, relief="flat",
                  activebackground="#8e0000", activeforeground="white", padx=12, pady=6).pack(side="left", padx=6)
    def copiar():
        j.clipboard_clear(); j.clipboard_append(id_maquina); j.update()
    def imp():
        if importar(): res["ok"] = True; j.destroy()
    botao("Copiar ID", copiar)
    botao("Site da VENG", lambda: webbrowser.open("https://video.eng.br"))
    botao("Importar licença…", imp, VERMELHO)
    botao("Fechar", j.destroy)
    copiar()
    j.grab_set(); j.focus_force(); root.wait_window(j)
    return res["ok"]

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "expirado":
        r = tk.Tk(); r.withdraw()
        print(expirado("teste", "Versão free expirada em 05/11/2026 (30 dias de uso).", "XXXX-ID-TESTE", r, lambda: False))
    else:
        mostrar("teste", "Licenciado para Fulano (Empresa)")
