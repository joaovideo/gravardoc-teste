@echo off
rem Gera "dist\Gravar Doc\Gravar Doc.exe" (compilado com Nuitka) e dist\GravarDoc-win.zip
rem (c) 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
rem Requer o venv criado pelo instalar.bat. Na 1a vez o Nuitka baixa o compilador C (MinGW64).
setlocal
chcp 65001 >nul
cd /d "%~dp0"
for /f tokens^=2^ delims^=^" %%a in ('findstr /b "VERSAO" app_gravardoc_win.py') do set VER=%%a
if "%VER%"=="" (echo ERRO: VERSAO nao encontrada em app_gravardoc_win.py & exit /b 1)
echo == Gravar Doc %VER%: build Windows ==

rem Cache do Nuitka (MinGW) fora do AppData: dentro de apps empacotados (MSIX) o AppData e virtualizado
rem e a extracao do compilador fica incompleta (faltam headers como psdk_inc\intrin-impl.h)
if not defined NUITKA_CACHE_DIR set "NUITKA_CACHE_DIR=%USERPROFILE%\.nuitka-cache"

venv\Scripts\python -m pip -q install nuitka zstandard -r requirements-win.txt || exit /b 1
if not exist build mkdir build
venv\Scripts\python icone_win.py build\gravardoc.ico || exit /b 1

venv\Scripts\python -m nuitka --standalone --windows-console-mode=disable ^
  --windows-icon-from-ico=build\gravardoc.ico ^
  --product-name="Gravar Doc" --company-name="V-Engine / VENG Projetos e Tecnologia Ltda." ^
  --file-description="Gravar Doc - captura de tela e audio a 23,976 fps" ^
  --copyright="© 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados." ^
  --file-version=%VER%.0 --product-version=%VER%.0 ^
  --enable-plugin=tk-inter ^
  --include-module=gravar_doc_win --include-module=licenca --include-module=splash_win --include-module=icone_win ^
  --include-package=obsws_python --include-package=websocket ^
  --nofollow-import-to=nuitka --nofollow-import-to=gravar_doc --nofollow-import-to=splash ^
  --output-dir=build --output-filename="Gravar Doc.exe" --assume-yes-for-downloads ^
  app_gravardoc_win.py || exit /b 1

if exist "dist\Gravar Doc" rmdir /s /q "dist\Gravar Doc"
if not exist dist mkdir dist
xcopy /e /i /q /y "build\app_gravardoc_win.dist" "dist\Gravar Doc" >nul || exit /b 1

rem Conferencias: nenhum codigo-fonte Python e nenhuma chave privada no pacote
dir /s /b "dist\Gravar Doc\*.py" 2>nul | findstr . >nul && (echo ERRO: ha arquivos .py no pacote & exit /b 1)
dir /s /b "dist\Gravar Doc\*chave_privada*" "dist\Gravar Doc\*.key" "dist\Gravar Doc\gerador" 2>nul | findstr . >nul && (echo ERRO: chave privada/gerador no pacote & exit /b 1)

if exist dist\GravarDoc-win.zip del dist\GravarDoc-win.zip
powershell -NoProfile -Command "Compress-Archive -Path 'dist\Gravar Doc' -DestinationPath 'dist\GravarDoc-win.zip'" || exit /b 1
echo OK: dist\GravarDoc-win.zip (Gravar Doc %VER%)
