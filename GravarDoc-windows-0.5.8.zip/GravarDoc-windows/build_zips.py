#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =====================================================================================
#  Gravar Doc — empacota os zips de distribuição a partir do HEAD do git
#  © 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
#
#  dist/GravarDoc-windows-<versão>.zip    pasta GravarDoc-windows/ (repo inteiro sem gerador/) — extrair e
#                                         rodar instalar.bat
#  dist/GravarDoc-mac-fonte-<versão>.zip  pasta GravarDoc-mac-fonte/ (só o que o Mac usa)
#
#  O nome SEMPRE leva a versão (VERSAO de app_gravardoc_win.py): zip genérico "GravarDoc-windows.zip" já fez
#  instalar versão velha sem ninguém perceber (07/10/2026). Usa `git archive` (respeita o .gitattributes: .bat/.ps1
#  em CRLF), então só entra o que está COMMITADO. O gerador de licenças nunca entra.
#  Uso: python build_zips.py
# =====================================================================================
import io, os, shutil, subprocess, tarfile, zipfile

REPO = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(REPO, "dist"); os.makedirs(DIST, exist_ok=True)
TMP = os.path.join(DIST, "_arch"); shutil.rmtree(TMP, ignore_errors=True); os.makedirs(TMP)
TAR = os.path.join(DIST, "_head.tar")
subprocess.run(["git", "archive", "--format=tar", "-o", TAR, "HEAD"], cwd=REPO, check=True)
with tarfile.open(TAR) as t: t.extractall(TMP)
os.remove(TAR)
shutil.rmtree(os.path.join(TMP, "gerador"), ignore_errors=True)

def versao():
    for l in io.open(os.path.join(TMP, "app_gravardoc_win.py"), encoding="utf-8"):
        if l.startswith("VERSAO"): return l.split('"')[1]
    raise SystemExit("VERSAO não encontrada em app_gravardoc_win.py")
V = versao()
if subprocess.run(["git", "status", "--porcelain"], cwd=REPO, capture_output=True, text=True).stdout.strip():
    print("AVISO: há alterações não commitadas — o zip leva só o que está no HEAD.")

def zipar(nome, pasta, filtro):
    out = os.path.join(DIST, nome)
    if os.path.exists(out): os.remove(out)
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(TMP):
            dirs[:] = [d for d in dirs if d not in ("gerador", "__pycache__")]
            for f in files:
                full = os.path.join(root, f); rel = os.path.relpath(full, TMP).replace("\\", "/")
                if filtro(rel): z.write(full, pasta + "/" + rel); n += 1
    print(f"OK {out} ({n} arquivos, {os.path.getsize(out)} bytes)")

zipar(f"GravarDoc-windows-{V}.zip", "GravarDoc-windows", lambda r: True)
MAC = {".gitignore", "CHANGELOG.md", "LICENCA.txt", "README.md", "app_gravardoc.py", "build_mac.sh", "config.json",
       "gravar_doc.py", "instalar.command", "licenca.py", "requirements.txt", "splash.py", "ferramentas/obs_4pistas.py"}
zipar(f"GravarDoc-mac-fonte-{V}.zip", "GravarDoc-mac-fonte", lambda r: r in MAC or r.startswith("docs/"))
shutil.rmtree(TMP, ignore_errors=True)
print(f"Gravar Doc {V}")
