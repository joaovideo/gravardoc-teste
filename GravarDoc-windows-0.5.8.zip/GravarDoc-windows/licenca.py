# -*- coding: utf-8 -*-
# Gravar Doc — módulo de licenciamento
# © 2026 V-Engine (divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.)
# Todos os direitos reservados. Uso permitido somente mediante licença válida emitida pela V-Engine.
"""Licença = JSON assinado com Ed25519. A chave privada fica só com a V-Engine (pasta gerador/);
o app carrega apenas a chave pública abaixo. Campos: produto, licenciado, empresa, maquina
(UUID de hardware ou "*"), emissao, expira (AAAA-MM-DD ou "nunca"), assinatura."""
import base64, json, platform, subprocess, time
from pathlib import Path

PRODUTO = "GravarDoc"
# Edição free: uso livre por DIAS_TESTE dias a partir do 1º uso em cada máquina; depois exige licenca.json
# assinado pela V-Engine (que sempre tem prioridade). Propriedade intelectual da V-Engine/VENG (Lei 9.609/1998).
# Para a edição só licenciada, mude FREEWARE para False (a licença embutida/arquivo volta a valer).
FREEWARE = True
DIAS_TESTE = 30
CHAVE_PUBLICA = "nl3G0fiQrS/RgdRtocPvVliNhj7dkSMBl8suFpRJg2U="   # V-Engine — não alterar
# Licença de avaliação embutida (assinada, expira sozinha). Um licenca.json válido no disco tem prioridade.
LICENCA_EMBUTIDA = '{"produto":"GravarDoc","licenciado":"VENG — avaliação projeto Netflix","empresa":"V-Engine","maquina":"*","emissao":"2026-10-06","expira":"2026-11-05","emissor":"V-Engine / VENG Projetos e Tecnologia Ltda.","assinatura":"0o/baZk/Dw4CBUKxgvdkfExcGVnZ7uzww447Z1A6p/k8CB9hFsdjX62frFT6We/fFgr1/FktrW0n77AN8hLGBw=="}'
if platform.system() == "Windows":
    import os
    ARQUIVO = Path(os.environ.get("APPDATA", Path.home() / "AppData/Roaming")) / "GravarDoc" / "licenca.json"
else:
    ARQUIVO = Path.home() / "Library/Application Support/GravarDoc" / "licenca.json"
_LEGADO = Path(__file__).resolve().parent / "licenca.json"
if not ARQUIVO.exists() and _LEGADO.exists():
    ARQUIVO.parent.mkdir(parents=True, exist_ok=True); ARQUIVO.write_bytes(_LEGADO.read_bytes())

def id_maquina():
    """UUID de hardware: macOS (IOPlatformUUID) ou Windows (MachineGuid)."""
    try:
        if platform.system() == "Darwin":
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True, text=True).stdout
            return out.split('"IOPlatformUUID" = "')[1].split('"')[0]
        if platform.system() == "Windows":
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                return winreg.QueryValueEx(k, "MachineGuid")[0].upper()
    except Exception:
        pass
    return "DESCONHECIDO"

def _marcas_inicio():
    """Onde a data do 1º uso fica guardada (duas cópias; vale a mais antiga)."""
    if platform.system() == "Windows":
        import os
        return [ARQUIVO.parent / "inicio", Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "V-Engine" / ".gd"]
    return [ARQUIVO.parent / "inicio", Path.home() / "Library/Preferences/.br.vengine.gd"]

def _inicio_teste():
    import datetime as dt
    datas = []
    for m in _marcas_inicio():
        try: datas.append(dt.date.fromisoformat(m.read_text().strip()))
        except Exception: pass
    ini = min(datas) if datas else dt.date.today()
    for m in _marcas_inicio():
        try: m.parent.mkdir(parents=True, exist_ok=True); m.write_text(ini.isoformat())
        except OSError: pass
    return ini

def _relogio_ok(hoje):
    """Bloqueia relógio atrasado para burlar validade: guarda a última data vista."""
    marca = Path(ARQUIVO).parent / "ultimo_uso"
    try:
        ultimo = marca.read_text().strip() if marca.exists() else hoje
        if hoje < ultimo: return False, ultimo
        marca.parent.mkdir(parents=True, exist_ok=True); marca.write_text(hoje)
    except OSError:
        pass
    return True, hoje

def _payload(d):
    return json.dumps({k: d[k] for k in sorted(d) if k != "assinatura"}, separators=(",", ":"), ensure_ascii=False).encode()

def verificar(caminho=ARQUIVO):
    """Retorna (ok, mensagem, dados)."""
    if FREEWARE and Path(caminho).exists() and caminho == ARQUIVO:
        # licenca.json antigo (vencido, de outra máquina, de teste): na edição free não bloqueia — cai no período free
        ok, m, d = verificar_arquivo(caminho)
        if ok: return ok, m, d
    if FREEWARE and (caminho == ARQUIVO or not Path(caminho).exists()):
        import datetime as dt
        hoje = time.strftime("%Y-%m-%d"); ok, ultimo = _relogio_ok(hoje)
        if not ok:
            return False, f"Data do sistema ({hoje}) anterior ao último uso ({ultimo}). Acerte o relógio.", None
        fim = _inicio_teste() + dt.timedelta(days=DIAS_TESTE)
        resta = (fim - dt.date.today()).days
        d = {"produto": PRODUTO, "licenciado": "Versão free", "empresa": "V-Engine / VENG", "expira": fim.isoformat()}
        if resta <= 0:
            return False, f"Versão free expirada em {fim.strftime('%d/%m/%Y')} ({DIAS_TESTE} dias de uso). Peça a licença à VENG.", d
        return True, f"Versão free — {resta} dia(s) restante(s), até {fim.strftime('%d/%m/%Y')}.", d
    return verificar_arquivo(caminho)

def verificar_arquivo(caminho=ARQUIVO):
    """Valida um licenca.json assinado (ou a licença embutida). Retorna (ok, mensagem, dados)."""
    try:
        if Path(caminho).exists():
            d = json.loads(Path(caminho).read_text(encoding="utf-8-sig"))   # aceita BOM (Bloco de Notas do Windows)
        elif LICENCA_EMBUTIDA:
            d = json.loads(LICENCA_EMBUTIDA)
        else:
            return False, f"Licença não encontrada ({Path(caminho).name}).", None
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        Ed25519PublicKey.from_public_bytes(base64.b64decode(CHAVE_PUBLICA)).verify(base64.b64decode(d["assinatura"]), _payload(d))
    except Exception as e:
        return False, f"Licença inválida ou adulterada ({type(e).__name__}).", None
    if d.get("produto") != PRODUTO:
        return False, "Licença é de outro produto.", d
    if d.get("maquina", "*") not in ("*", id_maquina()):
        return False, "Licença emitida para outra máquina.", d
    exp = d.get("expira", "nunca")
    hoje = time.strftime("%Y-%m-%d")
    if exp != "nunca":
        ok, ultimo = _relogio_ok(hoje)
        if not ok:
            return False, f"Data do sistema ({hoje}) anterior ao último uso ({ultimo}). Acerte o relógio.", d
    if exp != "nunca" and hoje > exp:
        return False, f"Licença expirada em {exp}.", d
    return True, f"Licenciado para {d.get('licenciado')} ({d.get('empresa')}) até {exp}.", d

def exigir(dialog):
    """Chamado pelo app: aborta com diálogo se a licença não for válida."""
    ok, msg, _ = verificar()
    if not ok:
        dialog("Gravar Doc — Licença", f"{msg}\n\nID desta máquina:\n{id_maquina()}\n\n"
               "Envie este ID para a V-Engine (VENG) e importe a licença pelo menu Gravar Doc > Importar licença.", ok=False)
        raise SystemExit(2)
    return msg
