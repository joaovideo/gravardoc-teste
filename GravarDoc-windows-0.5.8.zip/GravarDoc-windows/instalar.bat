@echo off
rem Gravar Doc - instalador Windows (c) 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
pause
