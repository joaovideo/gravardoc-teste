# Arquitetura

## Visão geral

```
1 PREPARAR.app ─┐                          ┌─ ~/Library/Application Support/obs-studio/
2 GRAVAR-PARAR ─┴─ venv/python gravar_doc.py ─┤    basic/profiles/<perfil>/basic.ini   (saída, vídeo, áudio)
                    │                         │    basic/scenes/<coleção>.json         (cenas e fontes)
                    │                         │    plugin_config/obs-websocket/config.json
                    ├─ licenca.py (bloqueia sem licença)
                    ├─ displayplacer (refresh 47,95 Hz / restauração)
                    ├─ osascript / System Events (abrir e maximizar WhatsApp)
                    ├─ obs-websocket :4455 (obsws-python) → validação e Start/StopRecord
                    └─ ffmpeg / ffprobe (tela preta, validação do arquivo)
```

Os `.app` são AppleScripts compilados (`osacompile`) que chamam o Python do venv; recompilados pelo `instalar.command`.

## Por que reescrever a configuração do OBS a cada PREPARAR

A configuração é o ponto mais frágil de uma gravação longa: qualquer clique numa sessão anterior pode mudar FPS, encoder ou pistas. O PREPARAR fecha o OBS e reescreve perfil, cenas e websocket a partir do template embutido no código, então todo dia começa do mesmo estado conhecido. Consequência: alterações manuais no perfil/coleção `Untitled` são perdidas (ver pendências).

## Decisões técnicas

| Decisão | Motivo |
|---|---|
| 24000/1001 como FPS fracionário (`FPSType=2`) | é o 23,976 exato; o preset "24 NTSC" é equivalente, mas o fracionário não deixa dúvida |
| ProRes 422 por hardware (`appleproreshw.422`) | intra‑frame, edição leve, quase sem carga de CPU/GPU no Apple Silicon |
| PCM 24‑bit em MOV | sem compressão de áudio; MOV entra direto no Resolve/Premiere com as 3 pistas |
| Captura por aplicativo (ScreenCaptureKit) | grava só a janela do app, ignora notificações e janelas por cima |
| Áudio por aplicativo (`sck_audio_capture`) | áudio decodificado direto do app, sem alto‑falante, sem BlackHole, sem eco |
| Sem "Áudio do desktop" global | evita áudio duplicado/eco |
| 47,95 Hz no MacBook Pro | 2 refreshes exatos por frame gravado → cadência perfeita em rolagem e vídeo |
| Websocket sem senha, só localhost | o script roda na mesma máquina; simplifica a automação |

## Fluxo do PREPARAR

1. `licenca.exigir()` — sem licença válida, mostra o ID da máquina e aborta.
2. Identifica o modelo (`system_profiler`), pasta de gravação (SSD externo se montado), espaço livre, energia.
3. Fecha o OBS (AppleScript, fallback `pkill`).
4. Escreve `basic.ini`, `Untitled.json`, `config.json` do websocket e ajusta `user.ini` (sem modo estúdio, sem confirmação ao sair).
5. MacBook Pro: `displayplacer` procura um modo 47,95/48 Hz na mesma resolução e salva o modo original em `state.json`.
6. Abre o WhatsApp, espera a janela, maximiza via System Events (exige Acessibilidade).
7. Abre o OBS com `--collection --profile --scene --disable-updater` e conecta no websocket.
8. Lê as configurações de vídeo e confere 24000/1001.
9. Escolhe o microfone: primeiro que case com `mic_hint`; senão o primeiro que não seja interno/virtual.
10. Screenshot da cena ativa → `ffmpeg signalstats` → luminância média; < 8 = captura preta.
11. Diálogo com relatório e alertas.

## Fluxo do GRAVAR‑PARAR

Alterna `StartRecord`/`StopRecord`. Ao parar: espera o arquivo fechar, roda `ffprobe` (codec, dimensões, `r_frame_rate`, número de frames × duração com tolerância de 1%, número e formato das pistas), restaura o refresh e mostra o resumo.

## Problemas já encontrados (e resolvidos)

| Sintoma | Causa | Solução no código |
|---|---|---|
| Captura do WhatsApp preta | o OBS iniciou antes do WhatsApp; o filtro do ScreenCaptureKit não se atualiza | PREPARAR abre o WhatsApp e espera a janela antes de abrir o OBS |
| `Invalid target display ID: 0` no log | `display_uuid` ausente na fonte | UUID do display principal obtido do `displayplacer` e gravado na fonte |
| "A saída de vídeo está ativa" ao mudar FPS | câmera virtual/saída ligada | o template não ativa câmera virtual; o PREPARAR fecha e reabre o OBS |
| Não maximiza o WhatsApp | falta permissão de Acessibilidade para o app | diálogo explica onde liberar |

## Limitações conhecidas

- MacBook Air: tela fixa em 60 Hz → cadência 2‑3 a 23,976 (imperceptível em chamada, visível em vídeo com movimento no Chrome).
- Vídeos do YouTube/Instagram a 30/60 fps gravados a 23,976 terão frames repetidos/pulados.
- O perfil e a coleção `Untitled` são sobrescritos a cada PREPARAR.
- iPhone fica fora do app (captura por hardware: HDMI + interface Bluetooth).
