# Operação — dia de gravação

## Checklist (5 minutos antes)

1. MacBook Pro **na tomada**, sobre superfície dura; SSD externo conectado (se usado).
2. Interface de áudio USB conectada e fone no protagonista (evita vazamento do interlocutor no mic).
3. Foco / Não Perturbe ligado; fechar iCloud Fotos, Time Machine e apps pesados.
4. WhatsApp e Chrome logados.
5. Clicar **1 PREPARAR** e ler o relatório. Só seguir com "TUDO PRONTO" ou com alertas conhecidos.
6. Claquete sonora (palma na frente do mic) no início, se não houver LTC.

## Durante

- **2 GRAVAR‑PARAR** para iniciar; notificação "GRAVANDO ●".
- Trocar de cena sem parar a gravação: ⌃⌥1 WhatsApp · ⌃⌥2 Chrome · ⌃⌥3 Tela inteira.
- Rodapé do OBS: FPS 23.98 / 23.98 e zero frames perdidos.
- Não abrir Ajustes do OBS com a gravação rodando.

## Depois

- **2 GRAVAR‑PARAR** para parar; ler o diálogo (codec, fps, duração, pistas). Qualquer "ALERTA" → anotar o arquivo e avisar a pós.
- O refresh da tela volta sozinho ao valor original.
- Copiar os `.mov` para o storage da produção no fim do dia.

## Solução de problemas

| Sintoma | Ação |
|---|---|
| "Licença não encontrada/expirada/outra máquina" | enviar o ID mostrado para a V‑Engine |
| Captura do WhatsApp PRETA | fechar OBS e WhatsApp, abrir o WhatsApp, rodar PREPARAR de novo |
| "Mic USB não encontrado" | conectar a interface e rodar PREPARAR; ou definir `mic_hint` no `config.json` |
| "nenhum modo 47.95 Hz" | máquina sem ProMotion (Air) ou resolução não padrão — seguir; cadência 2‑3 |
| Não maximizou o WhatsApp | liberar Acessibilidade para "1 PREPARAR" |
| "OBS não respondeu no websocket" | abrir o OBS manualmente uma vez; conferir se outro OBS está aberto |
| "Falha ao iniciar a gravação — veja o OBS" | o encoder do perfil não existe nesse OBS (ver `Encoder ID ... not found` no log do OBS); rodar PREPARAR de novo — desde a 0.5.3 (Windows) ele escolhe o encoder pelo log do OBS |
| "Na bateria" | ligar o carregador |
| "Pouco espaço" | conectar o SSD externo ou liberar disco |
| Áudio do interlocutor mudo | conferir se a chamada está no app WhatsApp Desktop (não no navegador) e a cena correta |

## Logs

- `gravar_doc.log` — último PREPARAR/GRAVAR com relatório.
- `run.log` — saída bruta dos apps clicáveis.
- Log do OBS: Ajuda › Arquivos de log.
