# Instalação (MacBook Pro de gravação)

## 1. Pré‑requisitos

1. macOS 14 ou superior, Apple Silicon.
2. [Homebrew](https://brew.sh).
3. OBS Studio 32.2+ em `/Applications` (build Apple Silicon).
4. WhatsApp Desktop (Mac App Store) e Google Chrome, com login feito.

## 2. Código

```bash
git clone https://github.com/joaovideo/gravar-doc.git ~/GravarDoc
cd ~/GravarDoc
./instalar.command
```

O instalador verifica cada dependência e, **se faltar alguma, pede autorização num diálogo do macOS antes de instalar**:

| Item | Se faltar | Obrigatório |
|---|---|---|
| Homebrew | instalador oficial (brew.sh); pede a senha de administrador no Terminal | sim |
| Python 3.11+, ffmpeg, displayplacer | `brew install` | sim |
| OBS Studio | `brew install --cask obs` | sim |
| WhatsApp, Google Chrome | `brew install --cask …` | não (a cena fica vazia) |

Depois recria o `venv` a partir do `requirements.txt`, compila "1 PREPARAR.app" e "2 GRAVAR‑PARAR.app" apontando para esta pasta, verifica a sintaxe e confere a `licenca.json` se houver uma (sem ela vale a versão free de 30 dias). Se a pasta mudar de lugar, rode o instalador de novo. Recusar uma dependência obrigatória encerra a instalação com mensagem.

## 3. Licença

Rode `open "1 PREPARAR.app"` uma vez. A edição free vale 30 dias por máquina; para estender, a V‑Engine emite uma `licenca.json` a partir do **ID desta máquina** (menu Gravar Doc > Copiar ID), importada pelo menu Gravar Doc > Importar licença. Um `licenca.json` antigo ou de outra máquina é ignorado, não bloqueia (0.5.6). Ver [LICENCIAMENTO.md](LICENCIAMENTO.md).

## 4. Permissões do macOS (uma vez)

| Permissão | App | Onde |
|---|---|---|
| Gravação de Tela e Áudio do Sistema | OBS | Ajustes › Privacidade e Segurança |
| Microfone | OBS | idem |
| Acessibilidade | 1 PREPARAR | idem (para maximizar o WhatsApp) |
| Automação (System Events, OBS, WhatsApp) | 1 PREPARAR | aparece como pergunta na 1ª execução |

Abra o OBS manualmente uma vez antes do primeiro PREPARAR para conceder as permissões dele.

## 5. `config.json`

| Chave | Padrão | Descrição |
|---|---|---|
| `rec_path` | `~/Movies/Netflix` | pasta de gravação interna |
| `external_volumes` | `["GRAVACAO","NETFLIX"]` | nomes de SSD externo; se montado, grava nele |
| `external_subdir` | `Netflix` | subpasta dentro do SSD |
| `min_free_gb` | 50 | alerta de espaço |
| `suffix` | `MAC` | sufixo do nome do arquivo |
| `width`, `height` | 1920, 1080 | resolução de saída |
| `fps_num`, `fps_den` | 24000, 1001 | 23,976 fps |
| `target_hz` | `[47.95, 48]` | refresh desejado no MacBook Pro, em ordem de preferência |
| `video_encoder` | `…appleproreshw.422` | encoder de gravação |
| `audio_encoder` | `ffmpeg_pcm_s24le` | PCM 24‑bit |
| `mic_hint` | `""` | parte do nome da interface USB (ex.: `Scarlett`) |
| `whatsapp_bundle`, `chrome_bundle` | bundle IDs | não alterar |
| `ws_port` | 4455 | websocket do OBS |
| `obs_profile`, `obs_collection` | `Untitled` | perfil e coleção sobrescritos |

## 6. Teste de aceitação

1. Clique "1 PREPARAR": o relatório deve mostrar `Tela: … → 47.95 Hz`, `OBS: 1920x1080 @ 24000/1001`, o nome da interface USB e `captura do WhatsApp OK`.
2. Faça uma chamada de teste de 5 minutos e grave com "2 GRAVAR‑PARAR".
3. O diálogo final deve mostrar `prores 1920x1080 24000/1001` e `3 pistas de áudio`, sem ALERTA.
4. Abra no Resolve e confira as 3 pistas e ausência de drift entre início e fim.
