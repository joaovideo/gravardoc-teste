﻿# =====================================================================================
#  Gravar Doc — instalador Windows 11
#  © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
#  Verifica e instala (com permissão, via winget) tudo o que o app precisa, recria o venv
#  e o atalho "Gravar Doc" (nesta pasta e na Área de Trabalho).
#  Executar pelo instalar.bat (duplo clique). -Sim responde 'sim' a todas as perguntas (instalação sem supervisão).
# =====================================================================================
param([switch]$Sim)
$ErrorActionPreference = 'Stop'
$AppDir = $PSScriptRoot
Set-Location $AppDir
Add-Type -AssemblyName System.Windows.Forms

function Ok($m)   { Write-Host "✔ $m" -ForegroundColor Green }
function Warn($m) { Write-Host "! $m" -ForegroundColor Yellow }
function Fail($m) {
    Write-Host "✘ $m" -ForegroundColor Red
    if (-not $Sim) { [System.Windows.Forms.MessageBox]::Show($m, 'Gravar Doc — Instalação', 'OK', 'Error') | Out-Null }
    exit 1
}
# Pergunta ao usuário (diálogo do Windows). Retorna $true se ele autorizar.
function Perguntar($m) {
    if ($Sim -or $script:Autorizado) { Write-Host "(sim) $($m.Split([char]10)[0])"; return $true }
    [System.Windows.Forms.MessageBox]::Show($m, 'Gravar Doc — Instalação', 'YesNo', 'Warning') -eq 'Yes'
}
function Recarregar-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
}
# $obrigatorio = $false: falha do winget vira aviso e a instalação SEGUE (07/10/2026: o WhatsApp, que é opcional,
# travou/falhou na Microsoft Store e derrubava o instalador inteiro). $script:WingetFalhou diz se a última falhou.
function Winget-Instalar($id, $nome, [string[]]$extra = @(), [bool]$obrigatorio = $true) {
    $script:WingetFalhou = $false
    Write-Host "Instalando $nome ($id)…"
    $args = @('install', '--id', $id, '-e', '--silent', '--accept-package-agreements', '--accept-source-agreements') + $extra
    if ($extra -contains 'msstore') {
        # Pacote da Microsoft Store: o winget pode ficar parado para sempre esperando a Loja (visto em 07/10/2026,
        # num PC sem conta na Loja). Limite de 15 s; estourou, mata o winget, abre a página do app na Loja (instala
        # com um clique) e a instalação do Gravar Doc segue.
        Write-Host "  (vem da Microsoft Store: até 15 segundos; se não concluir, a página da Loja abre para instalar com um clique)"
        $p = Start-Process -FilePath winget -ArgumentList $args -NoNewWindow -PassThru
        $null = $p.Handle            # sem isto o ExitCode vem vazio no PowerShell 5.1 (sem -Wait)
        if (-not $p.WaitForExit(15000)) {
            try { Stop-Process -Id $p.Id -Force } catch {}
            Get-Process winget -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            $script:WingetFalhou = $true
            Warn "A Microsoft Store não respondeu em 15 segundos. Abrindo a página do $nome na Loja: clique em Instalar/Obter. A instalação do Gravar Doc continua."
            Start-Process "ms-windows-store://pdp/?ProductId=$id"
            return
        }
        $global:LASTEXITCODE = $p.ExitCode
    } else {
        & winget @args
    }
    # 0 = instalado; -1978335189 = já instalado / sem atualização
    # -2147023673 (0x800704C7) = pedido de administrador (UAC) recusado ou não respondido
    if ($LASTEXITCODE -eq -2147023673) { Fail "A instalação de $nome precisa de permissão de administrador: clique em 'Sim' no aviso do Windows (UAC) e rode o instalar.bat de novo." }
    if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne -1978335189) {
        if ($obrigatorio) { Fail "Falha ao instalar $nome (winget $LASTEXITCODE)." }
        $script:WingetFalhou = $true
        Warn "Não deu para instalar $nome pelo winget (código $LASTEXITCODE). Instale depois pela Microsoft Store — a instalação do Gravar Doc continua."
        return
    }
    Recarregar-Path
}

Write-Host '== Gravar Doc: instalação (Windows) =='
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Fail 'O winget não está disponível. Atualize o "Instalador de Aplicativo" pela Microsoft Store e rode de novo.'
}

# Uma pergunta só: autoriza instalar tudo o que faltar (depois só o aviso do Windows/UAC)
$script:Autorizado = $false
if (-not $Sim) {
    $r = [System.Windows.Forms.MessageBox]::Show(
        "O Gravar Doc vai instalar o que faltar neste computador:`nPython, ffmpeg, OBS Studio, WhatsApp e Google Chrome.`n`nO Windows pode pedir permissão algumas vezes: clique em 'Sim'.`n`nContinuar?",
        'Gravar Doc — Instalação', 'YesNo', 'Question')
    if ($r -ne 'Yes') { Write-Host 'Instalação cancelada.'; exit 1 }
    $script:Autorizado = $true
}

# ---------------------------------------------------------------- 1. Python 3.11+ (ignora o atalho da Microsoft Store)
function Achar-Python {
    $cands = @()
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $p = (& py -3 -c 'import sys; print(sys.executable)' 2>$null); if ($p) { $cands += $p }
    }
    $cands += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue |
              Sort-Object FullName -Descending | ForEach-Object FullName
    foreach ($c in $cands) {
        if ($c -and ($c -notlike '*WindowsApps*') -and (Test-Path $c)) {
            & $c -c 'import sys; exit(sys.version_info < (3,11))' 2>$null
            if ($LASTEXITCODE -eq 0) { return $c }
        }
    }
    return $null
}
$Py = Achar-Python
if (-not $Py) {
    if (-not (Perguntar "O Python 3.12 não está instalado.`n`nEle roda o Gravar Doc. Instalar agora pelo winget?")) { Fail 'Instalação cancelada: o Python é necessário.' }
    Winget-Instalar 'Python.Python.3.12' 'Python 3.12'
    $Py = Achar-Python; if (-not $Py) { Fail 'Python instalado, mas não encontrado. Feche e abra o instalar.bat de novo.' }
}
Ok "Python $(& $Py -c 'import platform; print(platform.python_version())') ($Py)"

# ---------------------------------------------------------------- 2. ffmpeg (checagem de tela preta e validação do arquivo)
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -and -not (Test-Path "$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe")) {
    if (-not (Perguntar "O ffmpeg não está instalado.`n`nEle valida a captura e o arquivo gravado. Instalar agora pelo winget?")) { Fail 'Instalação cancelada: o ffmpeg é necessário.' }
    Winget-Instalar 'Gyan.FFmpeg' 'ffmpeg'
}
Ok 'ffmpeg'

# ---------------------------------------------------------------- 3. aplicativos (OBS obrigatório; WhatsApp e Chrome recomendados)
function Instalar-App($teste, $id, $nome, $obrigatorio, [string[]]$extra = @()) {
    if (& $teste) { Ok $nome; return }
    if (Perguntar "$nome não está instalado.`n`nInstalar agora pelo winget?") { Winget-Instalar $id $nome $extra $obrigatorio; if (-not $script:WingetFalhou) { Ok "$nome instalado" } }
    elseif ($obrigatorio) { Fail "$nome é necessário para o Gravar Doc." }
    else { Warn "$nome não instalado — a cena correspondente ficará vazia." }
}
$ObsExe = "$env:ProgramFiles\obs-studio\bin\64bit\obs64.exe"
Instalar-App { Test-Path $ObsExe } 'OBSProject.OBSStudio' 'OBS Studio' $true
Instalar-App { Get-AppxPackage -Name '5319275A.WhatsAppDesktop' } '9NKSQGP7F2NH' 'WhatsApp' $false @('--source', 'msstore')
Instalar-App { (Test-Path "$env:ProgramFiles\Google\Chrome\Application\chrome.exe") -or (Test-Path "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") } 'Google.Chrome' 'Google Chrome' $false

$ObsV = (Get-Item $ObsExe).VersionInfo.ProductVersion
if ([int]($ObsV.Split('.')[0]) -lt 32) { Warn "OBS $ObsV — recomendado 32.2 ou superior (winget upgrade OBSProject.OBSStudio)." }

# ---------------------------------------------------------------- 4. ambiente Python e atalhos clicáveis
if (Test-Path venv) { Remove-Item venv -Recurse -Force }
& $Py -m venv venv; if ($LASTEXITCODE) { Fail 'Falha ao criar o ambiente Python (venv).' }
& .\venv\Scripts\python.exe -m pip -q install --upgrade pip
& .\venv\Scripts\python.exe -m pip -q install -r requirements-win.txt; if ($LASTEXITCODE) { Fail 'Falha ao instalar as bibliotecas Python.' }
& .\venv\Scripts\python.exe -m py_compile gravar_doc_win.py licenca.py app_gravardoc_win.py splash_win.py icone_win.py; if ($LASTEXITCODE) { Fail 'Erro de sintaxe no Gravar Doc.' }
Ok 'Ambiente Python (obsws-python, cryptography, Pillow)'

$Shell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
& .\venv\Scripts\python.exe icone_win.py gravardoc.ico
# Um atalho só: 'Gravar Doc' (abre, prepara sozinho; clique no ícone perto do relógio = grava / para)
foreach ($dir in @($AppDir, $Desktop)) {
    foreach ($velho in @('1 PREPARAR', '2 GRAVAR-PARAR')) { Remove-Item (Join-Path $dir "$velho.lnk") -ErrorAction SilentlyContinue }
    $s = $Shell.CreateShortcut((Join-Path $dir 'Gravar Doc.lnk'))
    $s.TargetPath = Join-Path $AppDir 'venv\Scripts\pythonw.exe'
    $s.Arguments = "`"$(Join-Path $AppDir 'app_gravardoc_win.py')`""
    $s.WorkingDirectory = $AppDir
    $s.IconLocation = Join-Path $AppDir 'gravardoc.ico'
    $s.Description = 'Gravar Doc — abre, prepara e grava'
    $s.Save()
}
Ok "Atalho 'Gravar Doc' criado nesta pasta e na Área de Trabalho"

# ---------------------------------------------------------------- 5. próximos passos
& .\venv\Scripts\python.exe gravar_doc_win.py diagnostico
Write-Host ''
Ok 'PRONTO. Abrindo o Gravar Doc…'
Write-Host "Da próxima vez: dois cliques em 'Gravar Doc' na Área de Trabalho."
Write-Host "Para gravar: botão vermelho GRAVAR no canto da tela. Para terminar: PARAR."
if (-not $Sim) { Start-Process (Join-Path $AppDir 'venv\Scripts\pythonw.exe') -ArgumentList "`"$(Join-Path $AppDir 'app_gravardoc_win.py')`"" -WorkingDirectory $AppDir }
