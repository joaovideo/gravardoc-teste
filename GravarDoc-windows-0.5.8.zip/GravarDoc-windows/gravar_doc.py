#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =====================================================================================
#  Gravar Doc — projeto Netflix
#  © 2026 V-Engine, divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.
#  Todos os direitos reservados. Software proprietário: uso, cópia, modificação ou distribuição
#  somente mediante licença válida emitida pela V-Engine (ver LICENCA.txt e licenca.py).
# =====================================================================================
"""Gravar Doc (projeto Netflix) — prepara OBS + WhatsApp + tela para gravar videochamadas a 23,976 fps.
Uso:  gravar_doc.py preparar | gravar | status
  preparar : fecha OBS, reescreve perfil/cena, ajusta refresh (MacBook Pro), abre WhatsApp
             maximizado, abre OBS, detecta mic USB, valida tudo e avisa.
  gravar   : alterna gravação (inicia; se já estiver gravando, para, valida o arquivo com
             ffprobe e restaura o refresh da tela).
"""
import json, os, re, shutil, subprocess, sys, time, uuid, base64, tempfile, plistlib
from pathlib import Path
import licenca
os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "/usr/bin:/bin")
import logging; logging.getLogger("obsws_python").setLevel(logging.CRITICAL); logging.getLogger("websocket").setLevel(logging.CRITICAL)

HERE = Path(__file__).resolve().parent
# Dados do usuário (config, estado, log, licença) ficam fora do app, para funcionar empacotado
DATA = Path.home() / "Library/Application Support/GravarDoc"; DATA.mkdir(parents=True, exist_ok=True)
DEFAULT_CFG = {"rec_path": "~/Movies/Netflix", "external_volumes": ["GRAVACAO", "NETFLIX"], "external_subdir": "Netflix",
    "min_free_gb": 50, "suffix": "MAC", "width": 1920, "height": 1080, "fps_num": 24000, "fps_den": 1001,
    "target_hz": [47.95, 48], "video_encoder": "com.apple.videotoolbox.videoencoder.appleproreshw.422",
    "audio_encoder": "ffmpeg_pcm_s24le", "mic_hint": "", "whatsapp_bundle": "net.whatsapp.WhatsApp",
    "chrome_bundle": "com.google.Chrome", "ws_port": 4455, "obs_profile": "Untitled", "obs_collection": "Untitled"}
_cfg_file = DATA / "config.json"
if not _cfg_file.exists():
    _legacy = HERE / "config.json"
    _cfg_file.write_text(_legacy.read_text() if _legacy.exists() else json.dumps(DEFAULT_CFG, indent=2, ensure_ascii=False))
CFG = {**DEFAULT_CFG, **json.loads(_cfg_file.read_text())}
STATE = DATA / "state.json"
OBS_DIR = Path.home() / "Library/Application Support/obs-studio"
LOG = DATA / "gravar_doc.log"

def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    print(line); LOG.open("a").write(line + "\n")

def sh(cmd, check=False, timeout=60):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout)
    if check and r.returncode: raise RuntimeError(f"{cmd}: {r.stderr.strip()}")
    return r.stdout.strip()

def osa(script): return sh(["osascript", "-e", script])
def osa2(script):
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True); return r.stdout.strip(), r.stderr.strip()
def ax_ok():
    """True se este processo pode usar System Events (Acessibilidade liberada)."""
    _, err = osa2('tell application "System Events" to count windows of process "Finder"')
    return not ("1719" in err or "25211" in err or "assistive" in err.lower() or "acessibilidade" in err.lower())

def notify(title, msg):
    osa(f'display notification "{msg}" with title "{title}"')

RODAPE = "\n\n— Gravar Doc · © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. · video.eng.br"

def dialog(title, msg, ok=True):
    icon = "note" if ok else "stop"; msg = msg + RODAPE
    osa(f'display dialog "{msg}" with title "{title}" buttons {{"OK"}} default button 1 with icon {icon}')

# ---------------------------------------------------------------- máquina
def model_info():
    txt = sh("system_profiler SPHardwareDataType")
    name = re.search(r"Model Name:\s*(.+)", txt); chip = re.search(r"Chip:\s*(.+)", txt)
    return (name.group(1).strip() if name else "?", chip.group(1).strip() if chip else "?")

def is_pro():  return "MacBook Pro" in model_info()[0]
def on_ac():   return "AC Power" in sh("pmset -g batt")
def obs_running(): return sh("pgrep -x OBS") != ""

def quit_obs():
    if not obs_running(): return
    osa('tell application "OBS" to quit')
    for _ in range(20):
        if not obs_running(): return
        time.sleep(0.5)
    sh("pkill -x OBS"); time.sleep(1)

def rec_path():
    p = Path(CFG["rec_path"]).expanduser()
    for ext in CFG.get("external_volumes", []):
        v = Path("/Volumes") / ext
        if v.is_dir(): p = v / CFG.get("external_subdir", "Documentario"); break
    p.mkdir(parents=True, exist_ok=True); return p

def free_gb(p): return shutil.disk_usage(p).free / 1e9

# ---------------------------------------------------------------- refresh da tela
def dp_list(): return sh("displayplacer list") if shutil.which("displayplacer") else ""

def set_refresh(target_hz_list):
    """Troca a tela principal para o 1º hz da lista disponível na resolução atual. Retorna (ok, msg)."""
    txt = dp_list()
    if not txt: return False, "displayplacer não instalado (brew install displayplacer)"
    block = txt.split("Persistent screen id:")[1]           # 1º display = principal
    sid = block.split("\n")[0].strip()
    cur = re.search(r"mode (\d+): res:(\S+) hz:(\S+) color_depth:\d+( scaling:on)? <-- current", block)
    if not cur: return False, "não achei o modo atual"
    cur_mode, res, cur_hz, scaling = cur.group(1), cur.group(2), cur.group(3), bool(cur.group(4))
    modes = re.findall(r"mode (\d+): res:(\S+) hz:(\S+) color_depth:\d+( scaling:on)?", block)
    for hz in target_hz_list:
        for m, r, h, s in modes:
            if r == res and bool(s) == scaling and abs(float(h) - hz) < 0.01:
                if m == cur_mode: return True, f"tela já em {h} Hz"
                st = json.loads(STATE.read_text()) if STATE.exists() else {}
                st.update({"display_id": sid, "orig_mode": cur_mode, "orig_hz": cur_hz})
                STATE.write_text(json.dumps(st))
                sh(f'displayplacer "id:{sid} mode:{m}"'); time.sleep(2)
                return True, f"tela {res} → {h} Hz (era {cur_hz})"
    return False, f"nenhum modo {target_hz_list} Hz disponível em {res} (tela fixa em {cur_hz} Hz)"

def restore_refresh():
    if not STATE.exists(): return
    st = json.loads(STATE.read_text())
    if "orig_mode" in st and shutil.which("displayplacer"):
        sh(f'displayplacer "id:{st["display_id"]} mode:{st["orig_mode"]}"')
        log(f"tela restaurada para {st.get('orig_hz')} Hz")
        for k in ("display_id", "orig_mode", "orig_hz"): st.pop(k, None)
        STATE.write_text(json.dumps(st))

# ---------------------------------------------------------------- OBS: arquivos de configuração
PROFILE = CFG.get("obs_profile", "Untitled"); COLLECTION = CFG.get("obs_collection", "Untitled")
SCENE = "Tela inteira"; SCENE_WA = "Chamada WhatsApp"; SRC_VIDEO = "WhatsApp (tela)"; SRC_WA_AUDIO = "WhatsApp (audio interlocutor)"; SRC_MIC = "Mic protagonista"

def write_profile(rec_dir):
    d = OBS_DIR / "basic/profiles" / PROFILE; d.mkdir(parents=True, exist_ok=True)
    ini = f"""[General]
Name={PROFILE}

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD_%hh-%mm-%ss_{CFG.get('suffix','MAC')}
DelayEnable=false
Reconnect=true

[AdvOut]
Encoder=com.apple.videotoolbox.videoencoder.ave.avc
RecType=Standard
RecFilePath={rec_dir}
RecFormat2=mov
RecUseRescale=false
RecTracks=15
RecEncoder={CFG.get('video_encoder','com.apple.videotoolbox.videoencoder.appleproreshw.422')}
RecAudioEncoder={CFG.get('audio_encoder','ffmpeg_pcm_s24le')}
RecSplitFile=false
RecRB=false
AudioEncoder=CoreAudio_AAC
Track1Bitrate=320
Track2Bitrate=320
Track3Bitrate=320
Track4Bitrate=320

[Video]
BaseCX={CFG.get('width',1920)}
BaseCY={CFG.get('height',1080)}
OutputCX={CFG.get('width',1920)}
OutputCY={CFG.get('height',1080)}
FPSType=2
FPSNum={CFG.get('fps_num',24000)}
FPSDen={CFG.get('fps_den',1001)}
ScaleType=lanczos
ColorFormat=I420
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo
"""
    (d / "basic.ini").write_text(ini)
    # remove ajustes antigos de encoder que poderiam sobrescrever o template
    for f in ("recordEncoder.json", "streamEncoder.json"):
        (d / f).unlink(missing_ok=True)

def write_websocket_cfg():
    d = OBS_DIR / "plugin_config/obs-websocket"; d.mkdir(parents=True, exist_ok=True)
    f = d / "config.json"
    cfg = json.loads(f.read_text()) if f.exists() else {}
    cfg.update({"server_enabled": True, "server_port": CFG.get("ws_port", 4455),
                "auth_required": False, "alerts_enabled": False, "first_load": False})
    f.write_text(json.dumps(cfg, indent=2))

def write_user_ini():
    f = OBS_DIR / "user.ini"
    if not f.exists(): return
    t = f.read_text()
    for k, v in (("PreviewProgramMode", "false"), ("ConfirmOnExit", "false"), ("FirstRun", "false")):
        t = re.sub(rf"^{k}=.*$", f"{k}={v}", t, flags=re.M)
    f.write_text(t)

def _src(id_, name, settings, mixers=255):
    return {"prev_ver": 537001986, "name": name, "uuid": str(uuid.uuid4()), "id": id_, "versioned_id": id_,
            "settings": settings, "mixers": mixers, "sync": 0, "flags": 0, "volume": 1.0, "balance": 0.5,
            "enabled": True, "muted": False, "push-to-mute": False, "push-to-mute-delay": 0,
            "push-to-talk": False, "push-to-talk-delay": 0,
            "hotkeys": {"libobs.mute": [], "libobs.unmute": [], "libobs.push-to-mute": [], "libobs.push-to-talk": []},
            "deinterlace_mode": 0, "deinterlace_field_order": 0, "monitoring_type": 0, "private_settings": {}}

def _item(s, i, w, h):
    return {"name": s["name"], "source_uuid": s["uuid"], "visible": True, "locked": False, "rot": 0.0,
            "scale_ref": {"x": float(w), "y": float(h)}, "pos": {"x": 0.0, "y": 0.0}, "scale": {"x": 1.0, "y": 1.0},
            "align": 5, "bounds_type": 2, "bounds_align": 0, "bounds_crop": False,
            "bounds": {"x": float(w), "y": float(h)}, "crop_left": 0, "crop_top": 0, "crop_right": 0, "crop_bottom": 0,
            "id": i, "group_item_backup": False, "scale_filter": "disable", "blend_method": "default",
            "blend_type": "normal", "show_transition": {"duration": 0}, "hide_transition": {"duration": 0},
            "private_settings": {}}

def main_display_uuid():
    m = re.search(r"Persistent screen id:\s*(\S+)", dp_list())
    return m.group(1) if m else "37D8832A-2D66-02CA-B9F7-8F30A301B230"

def _hk(n):  # ⌃⌥1, ⌃⌥2, ⌃⌥3 para trocar de cena
    return {"OBSBasic.SelectScene": [{"key": f"OBS_KEY_{n}", "control": True, "alt": True}]}

def write_scene():
    w, h = CFG.get("width", 1920), CFG.get("height", 1080); wa = CFG.get("whatsapp_bundle", "net.whatsapp.WhatsApp")
    ch = CFG.get("chrome_bundle", "com.google.Chrome"); du = main_display_uuid()
    mic = _src("coreaudio_input_capture", SRC_MIC, {"device_id": "default"}, mixers=5)            # pistas 1+3 (compartilhado)
    # cena 1: WhatsApp (app + áudio do app)
    v1 = _src("screen_capture", SRC_VIDEO, {"type": 2, "application": wa, "display_uuid": du, "hide_cursor": False})
    a1 = _src("sck_audio_capture", SRC_WA_AUDIO, {"type": 1, "application": wa}, mixers=3)
    s1 = _src("scene", SCENE_WA, {"id_counter": 3, "custom_size": False, "items": [_item(v1, 1, w, h), _item(a1, 2, w, h), _item(mic, 3, w, h)]}); s1["hotkeys"] = _hk(2)
    # cena 2: Chrome (app + áudio do Chrome — YouTube, Instagram etc.)
    v2 = _src("screen_capture", "Chrome (tela)", {"type": 2, "application": ch, "display_uuid": du, "hide_cursor": True})
    a2 = _src("sck_audio_capture", "Chrome (audio)", {"type": 1, "application": ch}, mixers=3)
    s2 = _src("scene", "Chrome", {"id_counter": 3, "custom_size": False, "items": [_item(v2, 1, w, h), _item(a2, 2, w, h), _item(mic, 3, w, h)]}); s2["hotkeys"] = _hk(3)
    # cena 3: tela inteira (display + todo o áudio do sistema)
    v3 = _src("screen_capture", "Monitor (video)", {"type": 0, "display_uuid": du, "hide_cursor": False})
    a3 = _src("sck_audio_capture", "Audio do sistema", {"type": 0}, mixers=3)
    a4 = _src("sck_audio_capture", "WhatsApp (audio pista 4)", {"type": 1, "application": wa}, mixers=9)   # pistas 1+4
    s3 = _src("scene", "Tela inteira", {"id_counter": 4, "custom_size": False, "items": [_item(v3, 1, w, h), _item(a3, 2, w, h), _item(mic, 3, w, h), _item(a4, 4, w, h)]}); s3["hotkeys"] = _hk(1)
    doc = {"name": COLLECTION, "current_scene": SCENE, "current_program_scene": SCENE,
           "scene_order": [{"name": SCENE}, {"name": SCENE_WA}, {"name": "Chrome"}],
           "current_transition": "Cortar", "transition_duration": 0, "transitions": [], "saved_projectors": [],
           "groups": [], "modules": {"scripts-tool": [], "output-timer": {}},
           "sources": [mic, v1, a1, s1, v2, a2, s2, v3, a3, a4, s3]}
    d = OBS_DIR / "basic/scenes"; d.mkdir(parents=True, exist_ok=True)
    (d / f"{COLLECTION}.json").write_text(json.dumps(doc, indent=1, ensure_ascii=False))

# ---------------------------------------------------------------- WhatsApp
def open_whatsapp_maximized():
    sh("open -a WhatsApp"); ok = False
    if not ax_ok():
        time.sleep(4); osa('tell application "WhatsApp" to activate')
        return False, "WhatsApp aberto, mas SEM permissão de Acessibilidade para maximizar: Ajustes > Privacidade e Segurança > Acessibilidade > ative '1 PREPARAR' (e '2 GRAVAR-PARAR'), depois rode PREPARAR de novo"
    for _ in range(30):                                   # espera a janela existir
        if osa('tell application "System Events" to count windows of process "WhatsApp"') not in ("", "0"):
            ok = True; break
        time.sleep(0.5)
    if not ok: return False, "WhatsApp não abriu janela"
    # maximiza na tela principal (exige permissão de Acessibilidade para este app)
    bounds = osa('tell application "Finder" to get bounds of window of desktop')   # "0, 0, W, H"
    try:
        _, _, W, H = [int(x) for x in bounds.split(",")]
    except Exception:
        W, H = 1470, 956
    r = osa(f'tell application "System Events" to tell process "WhatsApp" to set {{position, size}} of window 1 to {{{{0, 25}}, {{{W}, {H - 25}}}}}')
    osa('tell application "WhatsApp" to activate')
    if "não permitido" in r.lower() or "not allowed" in r.lower():
        return True, "WhatsApp aberto, mas não consegui maximizar — libere Acessibilidade para o app Gravar Doc (Ajustes > Privacidade > Acessibilidade)"
    return True, f"WhatsApp aberto e maximizado ({W}x{H})"

# ---------------------------------------------------------------- OBS via websocket
def obs_connect(timeout=40):
    import obsws_python as obs
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            return obs.ReqClient(host="localhost", port=CFG.get("ws_port", 4455), password="", timeout=5)
        except Exception:
            time.sleep(1)
    raise RuntimeError("OBS não respondeu no websocket (porta %s)" % CFG.get("ws_port", 4455))

def launch_obs():
    sh(f'open -a OBS --args --collection "{COLLECTION}" --profile "{PROFILE}" --scene "{SCENE}" --disable-updater')
    return obs_connect()

def pick_mic(ws):
    """Escolhe o dispositivo de entrada: 1º que case com mic_hint; senão 1º que não seja interno/virtual."""
    items = ws.get_input_properties_list_property_items(SRC_MIC, "device_id").property_items
    names = [(i["itemName"], i["itemValue"]) for i in items]
    hint = CFG.get("mic_hint", "").lower(); bad = ("blackhole", "ndi", "teams", "zoom", "vb-", "virtual", "loopback", "iphone")
    chosen = None
    if hint: chosen = next(((n, v) for n, v in names if hint in n.lower()), None)
    if not chosen: chosen = next(((n, v) for n, v in names if "macbook" not in n.lower() and "default" not in v.lower() and not any(b in n.lower() for b in bad)), None)
    if chosen:
        ws.set_input_settings(SRC_MIC, {"device_id": chosen[1]}, True)
        return chosen[0], chosen[0].lower().find("macbook") < 0
    return "mic interno (nenhuma interface USB encontrada)", False

def frame_brightness(ws):
    """Média de luminância do preview (0-255) usando ffmpeg signalstats; None se ffmpeg ausente."""
    if not shutil.which("ffmpeg"): return None
    r = ws.get_source_screenshot(ws.get_current_program_scene().current_program_scene_name, "png", 320, 180, -1)
    data = base64.b64decode(r.image_data.split(",", 1)[1])
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f: f.write(data); p = f.name
    out = subprocess.run(["ffmpeg", "-v", "info", "-i", p, "-vf", "signalstats,metadata=print:file=-", "-f", "null", "-"],
                         capture_output=True, text=True).stdout
    os.unlink(p); m = re.search(r"YAVG=([\d.]+)", out)
    return float(m.group(1)) if m else None

# ---------------------------------------------------------------- fluxos
def preparar():
    rep = []; bad = []
    name, chip = model_info(); log(f"máquina: {name} ({chip})")
    rd = rec_path(); fg = free_gb(rd); rep.append(f"Pasta: {rd} — {fg:.0f} GB livres (~{fg/38:.1f} h de ProRes)")
    if fg < CFG.get("min_free_gb", 50): bad.append(f"Pouco espaço: {fg:.0f} GB")
    if not on_ac(): bad.append("Na bateria — ligue o carregador")
    quit_obs(); write_profile(rd); write_websocket_cfg(); write_user_ini(); write_scene(); log("config OBS reescrita")
    if is_pro():
        ok, msg = set_refresh(CFG.get("target_hz", [47.95, 48])); rep.append("Tela: " + msg); (None if ok else bad.append(msg))
    else:
        rep.append(f"Tela: {name} sem ProMotion — 60 Hz fixo (cadência 2-3, aceitável p/ chamada)")
    ok, msg = open_whatsapp_maximized(); rep.append(msg); (None if ok else bad.append(msg))
    time.sleep(2)                                          # WhatsApp precisa existir ANTES do OBS (filtro SCK)
    ws = launch_obs(); time.sleep(3)
    v = ws.get_video_settings(); fps = f"{v.fps_numerator}/{v.fps_denominator}"
    rep.append(f"OBS: {v.output_width}x{v.output_height} @ {fps} ({v.fps_numerator/v.fps_denominator:.3f} fps)")
    if (v.fps_numerator, v.fps_denominator) != (CFG.get("fps_num", 24000), CFG.get("fps_den", 1001)): bad.append("FPS errado no OBS")
    mic, is_usb = pick_mic(ws); rep.append(f"Mic: {mic}"); (None if is_usb else bad.append("Mic USB não encontrado — usando interno"))
    time.sleep(2); y = frame_brightness(ws)
    if y is None: rep.append("Vídeo: (ffmpeg ausente, sem checagem de tela preta)")
    elif y < 8: bad.append(f"Captura do WhatsApp PRETA (Y={y:.0f}) — reabra o WhatsApp e rode PREPARAR de novo")
    else: rep.append(f"Vídeo: captura do WhatsApp OK (Y={y:.0f})")
    rd2 = ws.get_record_directory().record_directory; rep.append(f"Grava em: {rd2}")
    osa('tell application "OBS" to activate')
    st = json.loads(STATE.read_text()) if STATE.exists() else {}; st["prepared_at"] = time.time(); STATE.write_text(json.dumps(st))
    txt = "\n".join(rep) + ("\n\nATENÇÃO:\n- " + "\n- ".join(bad) if bad else "\n\nTUDO PRONTO. Clique GRAVAR quando a chamada começar.")
    log(txt.replace("\n", " | ")); notify("Gravar Doc", "PRONTO" if not bad else f"{len(bad)} alerta(s)"); dialog("Gravar Doc — PREPARAR", txt, ok=not bad)

def verify_file(path):
    if not shutil.which("ffprobe"): return f"Arquivo: {path}"
    js = json.loads(sh(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path]))
    v = next(s for s in js["streams"] if s["codec_type"] == "video"); a = [s for s in js["streams"] if s["codec_type"] == "audio"]
    dur = float(js["format"].get("duration", 0)); nb = int(v.get("nb_frames", 0) or 0)
    exp = dur * CFG.get("fps_num", 24000) / CFG.get("fps_den", 1001)
    info = (f"{Path(path).name}\n{v['codec_name']} {v['width']}x{v['height']} {v['r_frame_rate']} — {dur/60:.1f} min\n"
            f"{len(a)} pistas de áudio ({a[0]['codec_name']} {a[0]['sample_rate']} Hz)")
    if nb and abs(nb - exp) > exp * 0.01: info += f"\nALERTA: {nb} frames, esperado ~{exp:.0f}"
    if v["r_frame_rate"] != f"{CFG.get('fps_num',24000)}/{CFG.get('fps_den',1001)}": info += "\nALERTA: fps do arquivo diferente de 23,976"
    return info

def gravar():
    ws = obs_connect(timeout=8)
    if not ws.get_record_status().output_active:
        ws.start_record(); time.sleep(1.5)
        if not ws.get_record_status().output_active: dialog("Gravar Doc", "Falha ao iniciar a gravação — veja o OBS", ok=False); return
        notify("Gravar Doc", "GRAVANDO ● (clique de novo para parar)"); log("gravação iniciada")
    else:
        path = ws.stop_record().output_path; log(f"parada: {path}")
        for _ in range(20):
            if Path(path).exists() and not ws.get_record_status().output_active: break
            time.sleep(0.5)
        time.sleep(1); info = verify_file(path); restore_refresh()
        log(info.replace("\n", " | ")); notify("Gravar Doc", "Gravação salva"); dialog("Gravar Doc — PARADO", info, ok="ALERTA" not in info)

def status():
    ws = obs_connect(timeout=5); r = ws.get_record_status(); v = ws.get_video_settings()
    print(f"gravando={r.output_active} tempo={r.output_timecode} fps={v.fps_numerator}/{v.fps_denominator}")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "preparar"
    try:
        log(licenca.exigir(dialog))            # bloqueia sem licença válida da V-Engine
        {"preparar": preparar, "gravar": gravar, "status": status}[cmd]()
    except Exception as e:
        log(f"ERRO: {e!r}"); dialog("Gravar Doc — ERRO", str(e), ok=False); sys.exit(1)
