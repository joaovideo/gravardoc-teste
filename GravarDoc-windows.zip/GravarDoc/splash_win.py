# -*- coding: utf-8 -*-
# Gravar Doc — tela de abertura Windows (marca, copyright, licença e divulgação V-Engine / VENG)
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
# Mesmo conteúdo e visual do splash.py (macOS), em tkinter.
import tkinter as tk

W, H = 560, 380
FUNDO = "#0d1117"; VERMELHO = "#e50914"; TEXTO = "#ebebeb"; CINZA = "#949494"
FONTE = "Segoe UI"

def mostrar(versao, licenca_txt, segundos=5.0, root=None):
    """Mostra a janela de abertura por alguns segundos (clique para fechar antes). Retorna a janela.
    Sem root, cria o próprio Tk e roda o loop (uso isolado/teste)."""
    proprio = root is None
    if proprio: root = tk.Tk(); root.withdraw()
    j = tk.Toplevel(root); j.overrideredirect(True); j.attributes("-topmost", True); j.configure(bg=FUNDO)
    sw, sh = j.winfo_screenwidth(), j.winfo_screenheight()
    j.geometry(f"{W}x{H}+{(sw - W) // 2}+{(sh - H) // 2 - 60}")
    tk.Frame(j, bg=VERMELHO, height=6).pack(fill="x", side="top")

    def lbl(texto, tam, cor, negrito=False, pady=0):
        tk.Label(j, text=texto, bg=FUNDO, fg=cor, font=(FONTE, tam, "bold" if negrito else "normal"),
                 justify="center").pack(pady=pady)

    lbl("V-ENGINE", 26, VERMELHO, True, (22, 0))
    lbl("divisão de desenvolvimento de software da VENG", 10, CINZA)
    lbl(f"Gravar Doc {versao}", 20, TEXTO, True, (22, 0))
    lbl("Captura de tela e áudio a 23,976 fps · WhatsApp · Chrome · Tela inteira", 10, CINZA)
    lbl(licenca_txt, 10, TEXTO, pady=(14, 0))
    rodape = tk.Frame(j, bg=FUNDO); rodape.pack(side="bottom", fill="x", pady=(0, 12))
    for texto, tam, cor, neg in (
            ("VENG Projetos e Tecnologia — engenharia de áudio, vídeo e broadcast\n"
             "Projetos AV · Transmissão ao vivo · Backup LTO · Treinamentos vMix e Resolume", 10, TEXTO, False),
            ("video.eng.br  ·  contato@video.eng.br", 10, VERMELHO, True),
            ("© 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.\n"
             "Software proprietário (Lei 9.609/1998). Uso somente mediante licença.", 8, CINZA, False)):
        tk.Label(rodape, text=texto, bg=FUNDO, fg=cor, font=(FONTE, tam, "bold" if neg else "normal"),
                 justify="center").pack(pady=(6, 0))

    def fechar(_=None):
        try: j.destroy()
        except tk.TclError: pass
        if proprio: root.quit()
    j.bind("<Button-1>", fechar)
    for w in j.winfo_children(): w.bind("<Button-1>", fechar)
    j.after(int(segundos * 1000), fechar)
    if proprio: root.mainloop()
    return j

if __name__ == "__main__":
    mostrar("teste", "Licenciado para Fulano (Empresa)")
