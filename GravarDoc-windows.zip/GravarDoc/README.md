# Gravar Doc

Automação de captura de tela e áudio para o **projeto Netflix**: videochamadas do WhatsApp, navegação no Chrome (YouTube, Instagram) e tela inteira, gravadas a **23,976 fps** com o áudio da fonte e o microfone do protagonista em pistas separadas, com dois cliques.

> © 2026 **V‑Engine**, divisão de desenvolvimento de software da **VENG Projetos e Tecnologia Ltda.** Software proprietário, repositório privado, uso mediante licença. Ver [LICENCA.txt](LICENCA.txt) e [docs/LICENCIAMENTO.md](docs/LICENCIAMENTO.md).

## O que faz

| Clique | App | Ação |
|---|---|---|
| 1 | **1 PREPARAR** | Verifica licença, disco e energia; fecha o OBS; reescreve perfil, cenas e websocket a partir do template; no MacBook Pro troca a tela para 47,95 Hz; abre o WhatsApp maximizado; abre o OBS; escolhe o microfone USB; valida FPS e captura não‑preta; mostra relatório |
| 2 | **2 GRAVAR‑PARAR** | Inicia a gravação; no clique seguinte para, valida o arquivo com `ffprobe` e restaura o refresh da tela |

Arquivo gerado: `AAAA-MM-DD_hh-mm-ss_MAC.mov` em `~/Movies/Netflix` (ou no SSD externo, se montado).

| Parâmetro | Valor |
|---|---|
| Vídeo | Apple ProRes 422 (hardware), 1920×1080, 24000/1001 fps, 10‑bit 4:2:2 |
| Áudio | PCM 24‑bit 48 kHz, 3 pistas: 1 mix · 2 fonte (WhatsApp/Chrome/sistema) · 3 microfone |
| Consumo | ~640 MB/min (~38 GB/hora) |

## Cenas do OBS

| Atalho | Cena | Vídeo | Áudio da pista 2 |
|---|---|---|---|
| ⌃⌥1 | Chamada WhatsApp | aplicativo WhatsApp | áudio do WhatsApp |
| ⌃⌥2 | Chrome | aplicativo Chrome | áudio do Chrome |
| ⌃⌥3 | Tela inteira | display principal | áudio de todo o sistema |

O microfone do protagonista entra nas três cenas (pistas 1 e 3).

## Requisitos

- macOS 14+ em Apple Silicon; **MacBook Pro 14"/16"** para a cadência exata de 47,95 Hz (no MacBook Air a tela fica em 60 Hz)
- OBS Studio 32.2+, WhatsApp Desktop, Google Chrome
- Homebrew com `displayplacer` e `ffmpeg`; Python 3.11+
- Licença válida (`licenca.json`) emitida pela V‑Engine

## Instalação rápida

```bash
git clone https://github.com/joaovideo/gravar-doc.git ~/GravarDoc
cd ~/GravarDoc && ./instalar.command
# copie a licenca.json para esta pasta
open "1 PREPARAR.app"
```

Passo a passo, permissões do macOS e `config.json`: [docs/INSTALACAO.md](docs/INSTALACAO.md).

## Windows (em teste)

```bat
git clone https://github.com/joaovideo/gravar-doc.git %USERPROFILE%\GravarDoc
%USERPROFILE%\GravarDoc\instalar.bat
```

Depois: dois cliques em **Gravar Doc** na Área de Trabalho. Ele prepara tudo sozinho e mostra um botão **● GRAVAR / ■ PARAR** no canto da tela (o botão não aparece na gravação). Detalhes: [docs/WINDOWS.md](docs/WINDOWS.md).

## Documentação

| Documento | Conteúdo |
|---|---|
| [docs/ARQUITETURA.md](docs/ARQUITETURA.md) | decisões técnicas, fluxo interno, formato dos arquivos do OBS, problemas já encontrados |
| [docs/INSTALACAO.md](docs/INSTALACAO.md) | instalação no MacBook Pro, permissões, parâmetros do `config.json` |
| [docs/OPERACAO.md](docs/OPERACAO.md) | checklist do dia de gravação e solução de problemas |
| [docs/LICENCIAMENTO.md](docs/LICENCIAMENTO.md) | licença local atual e migração futura para o V‑Engine License Server |
| [docs/WINDOWS.md](docs/WINDOWS.md) | versão Windows: especificação, implementação e pendências de teste |
| [CHANGELOG.md](CHANGELOG.md) | histórico de versões |

## Estrutura

```
gravar_doc.py        núcleo: preparar | gravar | status
licenca.py           verificação da licença (Ed25519, chave pública embutida)
config.json          parâmetros do projeto
instalar.command     instalador macOS (Homebrew + venv + apps clicáveis)
requirements.txt     obsws-python, cryptography
gravar_doc_win.py    núcleo Windows (em teste): preparar | gravar | status | diagnostico
instalar.bat/.ps1    instalador Windows (winget + venv + atalhos)
gerador/             gerador de licenças local (uso interno; chave privada NÃO versionada)
docs/                documentação técnica
```

## Projetos relacionados

- [vengine-license-server](https://github.com/joaovideo/vengine-license-server) — servidor de licenças central da V‑Engine (Cloudflare), com landing page e trial de 1 minuto. A integração com o Gravar Doc está planejada, não ativa.
