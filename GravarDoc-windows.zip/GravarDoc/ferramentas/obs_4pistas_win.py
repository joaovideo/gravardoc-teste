# -*- coding: utf-8 -*-
# Gravar Doc — ajuste direto no OBS (Windows): 4 pistas de áudio no arquivo gravado
#   1 = mix   2 = fonte (WhatsApp/Chrome/sistema, conforme a cena)   3 = microfone   4 = áudio do sistema
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda.
# Uso: feche o OBS, dê duplo clique neste arquivo (ou: python obs_4pistas_win.py), abra o OBS de novo.
#      Rodar DEPOIS do "1 PREPARAR" (o Preparar reescreve os arquivos e desfaz o ajuste).
import json, os, re, sys, uuid, shutil, subprocess
from pathlib import Path

OBS = Path(os.environ.get("APPDATA", Path.home() / "AppData/Roaming")) / "obs-studio"
PROFILE = OBS / "basic/profiles/Untitled/basic.ini"
SCENES = OBS / "basic/scenes/Untitled.json"
NOME = "Audio do sistema (pista 4)"
MIXERS = 1 | 8                       # pistas 1 e 4

def fim(msg, erro=False):
    print(("ERRO: " if erro else "") + msg)
    if sys.stdin and sys.stdin.isatty():
        input("\nAperte Enter para fechar.")
    sys.exit(1 if erro else 0)

out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq obs64.exe"], capture_output=True, text=True).stdout
if "obs64.exe" in out:
    fim("feche o OBS antes de rodar este script.", True)
for f in (PROFILE, SCENES):
    if not f.exists():
        fim(f"nao encontrei {f} - rode o '1 PREPARAR' primeiro.", True)
    shutil.copy2(f, f.with_suffix(f.suffix + ".bak"))

# 1. perfil: gravar 4 pistas
ini = PROFILE.read_text(encoding="utf-8-sig")
ini = re.sub(r"(?m)^RecTracks=.*$", "RecTracks=15", ini)
if "Track4Bitrate" not in ini:
    ini = ini.replace("Track3Bitrate=320", "Track3Bitrate=320\nTrack4Bitrate=320")
PROFILE.write_text(ini, encoding="utf-8")

# 2. cenas: captura de saída do sistema (WASAPI) compartilhada, em todas as cenas, só nas pistas 1 e 4
doc = json.loads(SCENES.read_text(encoding="utf-8-sig"))
src = next((s for s in doc["sources"] if s["name"] == NOME), None)
if src is None:
    modelo = next((s for s in doc["sources"] if s["id"] == "wasapi_output_capture"), None) \
          or next(s for s in doc["sources"] if s["id"].startswith("wasapi"))
    src = json.loads(json.dumps(modelo))
    src.update({"name": NOME, "uuid": str(uuid.uuid4()), "id": "wasapi_output_capture",
                "versioned_id": "wasapi_output_capture", "settings": {"device_id": "default"}, "mixers": MIXERS})
    doc["sources"].append(src)
src["mixers"] = MIXERS
for cena in (s for s in doc["sources"] if s["id"] == "scene"):
    itens = cena["settings"]["items"]
    if any(i.get("source_uuid") == src["uuid"] for i in itens):
        continue
    item = json.loads(json.dumps(itens[-1]))
    item.update({"name": NOME, "source_uuid": src["uuid"], "id": max(i["id"] for i in itens) + 1})
    itens.append(item); cena["settings"]["id_counter"] = item["id"]
SCENES.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
fim("OK: OBS configurado para 4 pistas (1 mix, 2 fonte, 3 microfone, 4 sistema).\n"
    "Abra o OBS e confira em Configuracoes > Saida > Gravacao: faixas 1-4 marcadas.")
