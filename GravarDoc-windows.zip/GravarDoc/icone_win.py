# -*- coding: utf-8 -*-
# Gravar Doc — ícone da bandeja e do .exe (desenhado em código, sem arquivo de imagem)
# © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
import sys
from PIL import Image, ImageDraw, ImageFont

def icone(estado="ocioso", tam=64):
    """◎ ocioso (anel vermelho), ◌ ocupado (anel amarelo), ● gravando (disco vermelho)."""
    img = Image.new("RGBA", (tam, tam), (0, 0, 0, 0)); d = ImageDraw.Draw(img); m = tam // 16
    if estado == "gravando":
        d.ellipse((m, m, tam - m, tam - m), fill="#e50914")
    else:
        cor = "#f5c518" if estado == "ocupado" else "#e50914"
        d.ellipse((m, m, tam - m, tam - m), fill="#0d1117", outline=cor, width=max(2, tam // 9))
        try: f = ImageFont.truetype("segoeuib.ttf", tam // 3)
        except OSError: f = ImageFont.load_default()
        d.text((tam / 2, tam / 2), "GD", fill="#ebebeb", font=f, anchor="mm")
    return img

def salvar_ico(caminho):
    icone(tam=256).save(caminho, format="ICO", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])

if __name__ == "__main__":
    salvar_ico(sys.argv[1] if len(sys.argv) > 1 else "gravardoc.ico")
