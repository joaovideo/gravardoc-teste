# Versão Windows — especificação e implementação

## Máquinas avaliadas

| | Workstation | Notebook |
|---|---|---|
| CPU | Intel i7 4ª geração | Intel i5‑1235U |
| RAM | 32 GB | 8 GB |
| GPU / encoder | Radeon RX 580 8 GB — AMD AMF | Iris Xe — Intel QuickSync |
| Disco | a definir | 256 GB SSD (exige SSD externo) |
| SO | Windows 11 Pro (decisão de 29/09/2026) — i7 4ª geração fora da lista oficial da Microsoft: instalação com bypass de TPM/CPU | Windows 11 Pro |
| Papel | **máquina Windows principal** | backup / segunda estação para Chrome |

**Máquina do teste real (decisão de 29/09/2026):** Intel i9 de 9ª geração + NVIDIA Quadro → encoder NVENC. A Quadro precisa de driver compatível com o NVENC nativo do OBS 31+ (driver 531 ou superior); com driver antigo o OBS não lista o encoder e o PREPARAR deve ser refeito após atualizar o driver.

## Parâmetros de gravação decididos

- Encoder: **H.264** por hardware — AMD AMF na workstation, QuickSync no notebook (o template escolhe pelo hardware presente).
- Perfil High, preset Quality, **CQP 14**, keyframe a cada 24 frames (1 s), sem B‑frames.
- 1920×1080, 24000/1001, 4:2:0 8‑bit.
- MOV, PCM 24‑bit 48 kHz, 3 pistas (mix / fonte / mic), igual ao Mac.
- Estimativa: 20–30 GB/hora. Transcodificar para ProRes na ingestão da pós, se necessário.

## Mapeamento das fontes

| Cena | macOS | Windows |
|---|---|---|
| WhatsApp | `screen_capture` app + `sck_audio_capture` app | `window_capture` (WGC) + `wasapi_process_output_capture` do WhatsApp |
| Chrome | idem com Chrome | idem com `chrome.exe` |
| Tela inteira | `screen_capture` display + áudio do sistema | `monitor_capture` + `wasapi_output_capture` |
| Mic | `coreaudio_input_capture` | `wasapi_input_capture` |

## Instalador Windows

Mesma lógica do macOS: verifica e instala com permissão via **winget** (nativo no Windows 11): OBS Studio, Python 3.12 e ffmpeg (obrigatórios); WhatsApp e Chrome (opcionais).

## Diferenças de implementação

- Refresh 24/48 Hz: resolução personalizada no AMD Adrenalin (ou CRU); aplicar via `ChangeDisplaySettingsEx` quando disponível.
- Janela do WhatsApp: maximizar com `ShowWindow` via `ctypes`.
- Não Perturbe: Focus Assist.
- Apps clicáveis: atalhos `.lnk` / `.bat` com ícone, ou empacotar com PyInstaller.
- ID de máquina: `MachineGuid` (já suportado em `licenca.py`).

## Pendências para iniciar

1. OBS 32.2+ instalado na workstation.
2. Sessão do Claude ligada à workstation.
3. Confirmar disco da workstation e modelo da interface de áudio.

## Implementação (0.5.0, em teste)

| Arquivo | Papel |
|---|---|
| `gravar_doc_win.py` | núcleo Windows: `preparar`, `gravar`, `status`, `diagnostico` (mesmo fluxo do `gravar_doc.py`) |
| `instalar.bat` → `instalar.ps1` | instala Python 3.12, ffmpeg, OBS, WhatsApp (Microsoft Store) e Chrome via winget, com diálogo de permissão; cria o venv e o atalho único `Gravar Doc` (pasta do app e Área de Trabalho; apaga os antigos `1 PREPARAR` / `2 GRAVAR-PARAR`) |
| `licenca.py` | mesma licença; no Windows o arquivo fica em `%APPDATA%\GravarDoc\licenca.json` e o ID é o `MachineGuid` |

Dados do usuário (config, estado, log, licença): `%APPDATA%\GravarDoc`. Configuração do OBS reescrita em `%APPDATA%\obs-studio`. Gravações em `%USERPROFILE%\Videos\Netflix`, ou no disco com rótulo `GRAVACAO`/`NETFLIX` se estiver conectado. Sufixo do arquivo: `WIN` (mude `suffix` no `config.json` de cada máquina, ex.: `WS`, `NB`).

### Como cada item da especificação foi resolvido

| Item | Implementação |
|---|---|
| Encoder | `video_encoder: "auto"` escolhe pelo **log do OBS** (encoders que ele carregou de fato no último início — o OBS só tem os do adaptador em que subiu; desde a 0.5.3 o PREPARAR confere de novo depois de abrir e troca se o escolhido não existir) e, sem log, pela GPU no registro, prioridade **NVENC > AMF > QuickSync > x264**: NVIDIA (GeForce/Quadro) → `obs_nvenc_h264_tex`, Radeon → `h264_texture_amf`, Intel → `obs_qsv11_v2`, nenhuma → `obs_x264` (com alerta). Ajustes em `recordEncoder.json`, iguais para todos: H.264, CQP 14, perfil High, preset de qualidade (NVENC p5/hq, AMF quality, QSV TU1), `keyint_sec` 1, sem B‑frames. Para forçar um encoder, ponha o ID em `video_encoder` no `config.json` |
| Formato | MOV, NV12 (4:2:0 8‑bit), 24000/1001, PCM 24‑bit, pistas 1+2+3 |
| Captura de janela | `window_capture` método WGC, casando pelo executável (`priority` 2); a janela real do WhatsApp é lida com `EnumWindows` antes de escrever a cena |
| Áudio por app | `wasapi_process_output_capture` do WhatsApp (`WhatsApp.Root.exe`) e do `chrome.exe` |
| Refresh | `EnumDisplaySettings` procura 48 Hz na resolução atual e aplica com `ChangeDisplaySettingsEx` (sem gravar no registro); restaura ao parar. Sem o modo, alerta para criar 48 Hz no Adrenalin/CRU |
| WhatsApp | aberto por `shell:AppsFolder\5319275A.WhatsAppDesktop_…!App`, maximizado com `ShowWindow(SW_MAXIMIZE)` |
| OBS | fechado com `taskkill` (WM_CLOSE, depois `/F`), aberto com `--disable-updater --disable-shutdown-check` a partir da pasta `bin\64bit` |
| Diálogos | `MessageBoxW`; notificações por toast do Windows |

### Não testado ainda

Escrito numa VM sem GPU, sem áudio e sem OBS. Falta validar na máquina de teste (i9 9ª geração + Quadro):

1. `instalar.bat` completo e `gravar_doc_win.py diagnostico`.
2. Encoder NVENC escolhido e ajustes do `recordEncoder.json` aplicados (conferir no OBS: Configurações > Saída > Gravação após o PREPARAR).
3. Captura WGC e áudio por processo do WhatsApp novo (WinUI) — se o executável não for `WhatsApp.Root.exe`, ajustar `whatsapp_exe` no `config.json`.
4. Modo 48 Hz no monitor da workstation.
5. Gravação de 10 min: `ffprobe` deve mostrar h264 High, 24000/1001, 3 pistas PCM.

### Painel de um botão e pacote

- `app_gravardoc_win.py` + `splash_win.py`: dois cliques em "Gravar Doc" → tela de abertura → prepara sozinho → janelinha no canto inferior direito com **● GRAVAR / ■ PARAR** (sempre por cima, sem minimizar, invisível para o OBS via `WDA_EXCLUDEFROMCAPTURE`). Links pequenos: "abrir gravações" e "preparar de novo". Sem ícone de bandeja (o Windows 11 esconde ícones novos). Linha de comando: `app_gravardoc_win.py --cli preparar|gravar|status|diagnostico|licenca`.
- `build_win.bat` → `dist\GravarDoc-win.zip` (pasta `Gravar Doc` com `Gravar Doc.exe`, compilado com Nuitka). O pacote não exige Python instalado; OBS, ffmpeg e WhatsApp continuam vindo do `instalar.bat` (ou manualmente).

### Ainda não portado

- Não Perturbe (Focus Assist).
