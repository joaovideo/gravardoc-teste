# Licenciamento

O Gravar Doc é software proprietário da **V‑Engine** (divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.), protegido pela Lei 9.609/1998. Termos em [../LICENCA.txt](../LICENCA.txt).

## Modelo atual (0.3.0): licença local assinada

- `licenca.json` na pasta do app contém: produto, licenciado, empresa, ID de máquina (ou `*`), emissão, expiração (ou `nunca`), emissor e **assinatura Ed25519**.
- `licenca.py` embute só a **chave pública**; verifica assinatura, produto, máquina e validade a cada execução. Sem licença válida, o app mostra o ID da máquina e para.
- O ID de máquina é o `IOPlatformUUID` no macOS e o `MachineGuid` no Windows.

### Emitir uma licença (uso interno V‑Engine)

```bash
cd ~/GravarDoc
./venv/bin/python gerador/gerar_licenca.py \
  --licenciado "Nome" --empresa "Produtora" \
  --maquina E91027BB-8DF5-5EEB-9918-663D8C142686 \
  --dias 365 --saida licenca.json
```

- `--maquina "*"` → válida em qualquer máquina.
- `--dias 0` → sem expiração.
- Cada emissão é registrada em `gerador/emitidas.log`.

### Chave privada

`gerador/chave_privada.key` **não está no repositório** (`.gitignore`). Ela existe só no MacBook Air de desenvolvimento e precisa ser copiada para um cofre de senhas. Quem a tiver emite licenças válidas; se for perdida, é preciso gerar novo par e reemitir todas as licenças.

### Testes realizados (29/09/2026)

| Cenário | Resultado |
|---|---|
| Sem `licenca.json` | bloqueia |
| Licença válida para o Air de desenvolvimento | libera |
| JSON com um campo alterado | bloqueia (assinatura inválida) |
| Licença emitida para outra máquina | bloqueia |

## Modelo futuro: V‑Engine License Server

O [vengine-license-server](https://github.com/joaovideo/vengine-license-server) centraliza as licenças de todos os softwares V‑Engine (Cloudflare, plano gratuito): chaves `VENG-…`, assentos, revogação, trial self‑service de 1 minuto de gravação, landing page e download protegido. A migração do Gravar Doc para ele está **adiada** por decisão do João; quando for feita, `licenca.py` será substituído pelo `vengine_license.py` e a gravação trial será limitada a `max_record_seconds`.
