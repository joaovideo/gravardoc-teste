# -*- coding: utf-8 -*-
# =====================================================================================
#  Gravar Doc — app de barra de menus (macOS)
#  © 2026 V-Engine, divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.
#  Todos os direitos reservados. Software proprietário: uso somente com licença válida da V-Engine.
# =====================================================================================
import shutil, subprocess, sys, threading
from pathlib import Path

VERSAO = "0.5.0"

# Modo linha de comando (testes/automação): "Gravar Doc" --cli preparar|gravar|status|licenca
if len(sys.argv) >= 3 and sys.argv[1] == "--cli":
    import gravar_doc, licenca
    cmd = sys.argv[2]
    if cmd == "licenca":
        ok, msg, _ = licenca.verificar(); print(("OK " if ok else "BLOQUEADO ") + msg); print("ID:", licenca.id_maquina()); sys.exit(0 if ok else 2)
    licenca.exigir(gravar_doc.dialog)
    {"preparar": gravar_doc.preparar, "gravar": gravar_doc.gravar, "status": gravar_doc.status}[cmd](); sys.exit(0)

import rumps
import licenca

def osa(script):
    return subprocess.run(["osascript", "-e", script], capture_output=True, text=True).stdout.strip()

class App(rumps.App):
    def __init__(self):
        super().__init__("Gravar Doc", title="◎ GD", quit_button=None)
        self.ocupado = False
        self.item_status = rumps.MenuItem("…")
        self.item_preparar = rumps.MenuItem("1  Preparar", callback=self.preparar, key="p")
        self.item_gravar = rumps.MenuItem("2  Gravar / Parar", callback=self.gravar, key="g")
        self.menu = [self.item_status, None, self.item_preparar, self.item_gravar, None,
                     rumps.MenuItem("Importar licença…", callback=self.importar),
                     rumps.MenuItem("Copiar ID desta máquina", callback=self.copiar_id),
                     rumps.MenuItem("Abrir pasta de gravações", callback=self.abrir_pasta),
                     None, rumps.MenuItem("Sobre o Gravar Doc", callback=self.sobre),
                     rumps.MenuItem("Sair", callback=lambda _: rumps.quit_application())]
        self.atualizar_licenca()
        self._splash = None
        self._t_splash = rumps.Timer(self._abrir_splash, 0.5); self._t_splash.start()

    def _abrir_splash(self, t):
        t.stop()
        try:
            import splash
            ok, msg, d = licenca.verificar()
            txt = msg if ok else "Versão expirada — sem licença para esta máquina"
            self._splash = splash.mostrar(VERSAO, txt)
        except Exception as e:
            print("splash:", e)

    # ------------------------------------------------------------ licença
    def atualizar_licenca(self):
        ok, msg, d = licenca.verificar()
        self.licenciado = ok
        self.item_status.title = (f"✔ {d.get('licenciado')} — até {d.get('expira')}" if ok else "✘ Sem licença para esta máquina")
        for it in (self.item_preparar, self.item_gravar):
            it.set_callback(getattr(self, "preparar" if it is self.item_preparar else "gravar") if ok else None)
        return ok, msg

    def importar(self, _):
        caminho = osa('POSIX path of (choose file with prompt "Selecione o arquivo licenca.json enviado pela V-Engine" of type {"json", "public.json"})')
        if not caminho: return
        ok, msg, _ = licenca.verificar(caminho)
        if not ok:
            rumps.alert("Licença não aceita", f"{msg}\n\nID desta máquina:\n{licenca.id_maquina()}"); return
        licenca.ARQUIVO.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(caminho, licenca.ARQUIVO)
        self.atualizar_licenca(); rumps.alert("Licença ativada", msg)

    def copiar_id(self, _):
        mid = licenca.id_maquina(); subprocess.run(["pbcopy"], input=mid, text=True)
        rumps.notification("Gravar Doc", "ID copiado", mid)

    # ------------------------------------------------------------ ações
    def _rodar(self, nome):
        if self.ocupado: rumps.notification("Gravar Doc", "Aguarde", "Uma operação ainda está em andamento."); return
        ok, msg = self.atualizar_licenca()
        if not ok: rumps.alert("Gravar Doc — Licença", f"{msg}\n\nID desta máquina:\n{licenca.id_maquina()}\n\nUse 'Copiar ID' e envie à V-Engine."); return
        def job():
            self.ocupado = True
            try:
                import gravar_doc
                getattr(gravar_doc, nome)()
            except SystemExit: pass
            except Exception as e:
                import gravar_doc; gravar_doc.log(f"ERRO: {e!r}"); gravar_doc.dialog("Gravar Doc — ERRO", str(e), ok=False)
            finally:
                self.ocupado = False
        threading.Thread(target=job, daemon=True).start()

    @rumps.timer(3)
    def _tick(self, _):
        """Atualiza o título na thread principal: ◌ ocupado, ● REC gravando, ◎ ocioso."""
        if self.ocupado: self.title = "◌ GD"; return
        titulo = "◎ GD"
        if subprocess.run(["pgrep", "-x", "OBS"], capture_output=True).returncode == 0:
            try:
                import obsws_python as obs, gravar_doc
                c = obs.ReqClient(host="localhost", port=gravar_doc.CFG.get("ws_port", 4455), password="", timeout=1)
                if c.get_record_status().output_active: titulo = "● REC"
            except Exception: pass
        self.title = titulo

    def preparar(self, _): self._rodar("preparar")
    def gravar(self, _): self._rodar("gravar")

    def abrir_pasta(self, _):
        import gravar_doc; subprocess.run(["open", str(gravar_doc.rec_path())])

    def sobre(self, _):
        try:
            import splash; ok, msg, d = licenca.verificar()
            self._splash = splash.mostrar(VERSAO, f"Licenciado para {d.get('licenciado')}" if ok else "Sem licença", segundos=8)
        except Exception: pass
        ok, msg, _ = licenca.verificar()
        rumps.alert("Gravar Doc " + VERSAO,
                    "Captura de tela e áudio a 23,976 fps.\n\n"
                    "© 2026 V-Engine — divisão de desenvolvimento de software da\nVENG Projetos e Tecnologia Ltda. Todos os direitos reservados.\n"
                    "Software proprietário (Lei 9.609/1998). Uso, cópia ou distribuição\nsomente mediante licença da V-Engine.\n\n"
                    f"Licença: {msg}\nMáquina: {licenca.id_maquina()}\n\ncontato@video.eng.br")

if __name__ == "__main__":
    App().run()
