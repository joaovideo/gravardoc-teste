#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =====================================================================================
#  Gravar Doc — projeto Netflix (versão Windows)
#  © 2026 V-Engine, divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.
#  Todos os direitos reservados. Software proprietário: uso, cópia, modificação ou distribuição
#  somente mediante licença válida emitida pela V-Engine (ver LICENCA.txt e licenca.py).
# =====================================================================================
"""Gravar Doc (projeto Netflix) para Windows 11 — mesma lógica do gravar_doc.py (macOS).
Uso:  gravar_doc_win.py preparar | gravar | status | licenca
  preparar : fecha OBS, reescreve perfil/cenas (H.264 por hardware), ajusta refresh para 48 Hz
             se o monitor tiver o modo, abre WhatsApp maximizado, abre OBS, escolhe o mic USB,
             valida tudo e avisa.
  gravar   : alterna gravação (inicia; se já estiver gravando, para, valida o arquivo com
             ffprobe e restaura o refresh da tela).
"""
import json, os, re, shutil, subprocess, sys, time, uuid, base64, tempfile, string, winreg
import ctypes
from ctypes import wintypes
from pathlib import Path
import licenca
import logging; logging.getLogger("obsws_python").setLevel(logging.CRITICAL); logging.getLogger("websocket").setLevel(logging.CRITICAL)

# ffmpeg instalado pelo winget: WinGet\Links, ou (conta sem privilégio de symlink) só no PATH do usuário, que um
# processo aberto antes da instalação não enxerga — então relê o PATH do registro e procura na pasta de pacotes
def _path_registro():
    out = []
    for raiz, chave in ((winreg.HKEY_CURRENT_USER, "Environment"),
                        (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
        try:
            with winreg.OpenKey(raiz, chave) as k: out += os.path.expandvars(winreg.QueryValueEx(k, "Path")[0]).split(";")
        except OSError: pass
    return [Path(p) for p in out if p]
_la = Path(os.environ.get("LOCALAPPDATA", ""))
_extra = [_la / "Microsoft/WinGet/Links", *sorted(_la.glob("Microsoft/WinGet/Packages/Gyan.FFmpeg*/*/bin")), Path("C:/ffmpeg/bin"), *_path_registro()]
os.environ["PATH"] = os.pathsep.join(str(p) for p in _extra if p.is_dir()) + os.pathsep + os.environ.get("PATH", "")

HERE = Path(__file__).resolve().parent
APPDATA = Path(os.environ.get("APPDATA", Path.home() / "AppData/Roaming"))
DATA = APPDATA / "GravarDoc"; DATA.mkdir(parents=True, exist_ok=True)
DEFAULT_CFG = {"rec_path": "~/Videos/Netflix", "external_volumes": ["GRAVACAO", "NETFLIX"], "external_subdir": "Netflix",
    "min_free_gb": 50, "suffix": "WIN", "width": 1920, "height": 1080, "fps_num": 24000, "fps_den": 1001,
    "target_hz": [48], "set_refresh": True, "video_encoder": "auto", "cqp": 14,
    "audio_encoder": "ffmpeg_pcm_s24le", "mic_hint": "",
    "whatsapp_exe": ["WhatsApp.Root.exe", "WhatsApp.exe"],
    "whatsapp_aumid": "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App", "chrome_exe": "chrome.exe",
    "obs_exe": r"C:\Program Files\obs-studio\bin\64bit\obs64.exe",
    "ws_port": 4455, "obs_profile": "Untitled", "obs_collection": "Untitled"}
_cfg_file = DATA / "config.json"
if not _cfg_file.exists():
    _cfg_file.write_text(json.dumps(DEFAULT_CFG, indent=2, ensure_ascii=False), encoding="utf-8")
CFG = {**DEFAULT_CFG, **json.loads(_cfg_file.read_text(encoding="utf-8"))}
STATE = DATA / "state.json"
OBS_DIR = APPDATA / "obs-studio"
LOG = DATA / "gravar_doc.log"
GB_POR_HORA = 25                                   # H.264 CQP 14 a 1080p23,976 (estimativa da especificação: 20–30)
NO_WINDOW = 0x08000000                             # CREATE_NO_WINDOW: sem janela de console sob pythonw

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.MessageBoxW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT]

def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    print(line)
    with LOG.open("a", encoding="utf-8") as f: f.write(line + "\n")

def sh(cmd, check=False, timeout=60):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=timeout, creationflags=NO_WINDOW)
    if check and r.returncode: raise RuntimeError(f"{cmd}: {r.stderr.strip()}")
    return r.stdout.strip()

def notify(title, msg):
    """Notificação do Windows (toast) via PowerShell, sem bloquear."""
    q = lambda s: s.replace("'", "''")
    ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
          "$t = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
          f"$x = $t.GetElementsByTagName('text'); $x.Item(0).AppendChild($t.CreateTextNode('{q(title)}')) > $null;"
          f"$x.Item(1).AppendChild($t.CreateTextNode('{q(msg)}')) > $null;"
          "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
          "'{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe').Show([Windows.UI.Notifications.ToastNotification]::new($t))")
    try: subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], creationflags=NO_WINDOW)
    except Exception: pass

RODAPE = "\n\n— Gravar Doc · © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. · video.eng.br"

def dialog(title, msg, ok=True):
    # MB_OK | ícone (informação/erro) | MB_TOPMOST | MB_SETFOREGROUND
    user32.MessageBoxW(None, msg + RODAPE, title, 0x0 | (0x40 if ok else 0x10) | 0x40000 | 0x10000)

# ---------------------------------------------------------------- máquina
def _reg(path, name, root=winreg.HKEY_LOCAL_MACHINE):
    try:
        with winreg.OpenKey(root, path) as k: return str(winreg.QueryValueEx(k, name)[0]).strip()
    except OSError: return ""

def gpus():
    """Nomes das placas de vídeo instaladas (classe Display do registro)."""
    base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"; out = []
    for i in range(16):
        d = _reg(fr"{base}\{i:04d}", "DriverDesc")
        if d and d not in out: out.append(d)
    return out

def model_info():
    modelo = _reg(r"HARDWARE\DESCRIPTION\System\BIOS", "SystemProductName") or "?"
    cpu = _reg(r"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString") or "?"
    return modelo, cpu

class _SPS(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_byte), ("BatteryFlag", ctypes.c_byte), ("BatteryLifePercent", ctypes.c_byte),
                ("SystemStatusFlag", ctypes.c_byte), ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]

def on_ac():
    s = _SPS(); kernel32.GetSystemPowerStatus(ctypes.byref(s))
    return s.ACLineStatus != 0                     # 1 = tomada, 255 = desconhecido (desktop)

def obs_exe_name(): return Path(CFG["obs_exe"]).name
def obs_running(): return obs_exe_name().lower() in sh(["tasklist", "/FI", f"IMAGENAME eq {obs_exe_name()}", "/NH"]).lower()

def quit_obs():
    if not obs_running(): return
    sh(["taskkill", "/IM", obs_exe_name()])          # WM_CLOSE: o OBS fecha normalmente (ConfirmOnExit=false)
    for _ in range(20):
        if not obs_running(): return
        time.sleep(0.5)
    sh(["taskkill", "/F", "/IM", obs_exe_name()]); time.sleep(1)

def _volume_label(root):
    buf = ctypes.create_unicode_buffer(261)
    ok = kernel32.GetVolumeInformationW(ctypes.c_wchar_p(root), buf, 261, None, None, None, None, 0)
    return buf.value if ok else ""

def rec_path():
    p = Path(CFG["rec_path"]).expanduser()
    labels = {v.upper() for v in CFG.get("external_volumes", [])}
    for letra in string.ascii_uppercase[3:]:          # D: em diante
        raiz = f"{letra}:\\"
        if os.path.exists(raiz) and _volume_label(raiz).upper() in labels:
            p = Path(raiz) / CFG.get("external_subdir", "Netflix"); break
    p.mkdir(parents=True, exist_ok=True); return p

def free_gb(p): return shutil.disk_usage(p).free / 1e9

# ---------------------------------------------------------------- refresh da tela (ChangeDisplaySettingsEx)
class DEVMODEW(ctypes.Structure):
    _fields_ = [("dmDeviceName", wintypes.WCHAR * 32), ("dmSpecVersion", wintypes.WORD), ("dmDriverVersion", wintypes.WORD),
                ("dmSize", wintypes.WORD), ("dmDriverExtra", wintypes.WORD), ("dmFields", wintypes.DWORD),
                ("dmPositionX", wintypes.LONG), ("dmPositionY", wintypes.LONG),
                ("dmDisplayOrientation", wintypes.DWORD), ("dmDisplayFixedOutput", wintypes.DWORD),
                ("dmColor", ctypes.c_short), ("dmDuplex", ctypes.c_short), ("dmYResolution", ctypes.c_short),
                ("dmTTOption", ctypes.c_short), ("dmCollate", ctypes.c_short), ("dmFormName", wintypes.WCHAR * 32),
                ("dmLogPixels", wintypes.WORD), ("dmBitsPerPel", wintypes.DWORD), ("dmPelsWidth", wintypes.DWORD),
                ("dmPelsHeight", wintypes.DWORD), ("dmDisplayFlags", wintypes.DWORD), ("dmDisplayFrequency", wintypes.DWORD),
                ("dmICMMethod", wintypes.DWORD), ("dmICMIntent", wintypes.DWORD), ("dmMediaType", wintypes.DWORD),
                ("dmDitherType", wintypes.DWORD), ("dmReserved1", wintypes.DWORD), ("dmReserved2", wintypes.DWORD),
                ("dmPanningWidth", wintypes.DWORD), ("dmPanningHeight", wintypes.DWORD)]

ENUM_CURRENT = 0xFFFFFFFF
DM_BPP_W_H_HZ = 0x40000 | 0x80000 | 0x100000 | 0x400000

def _mode(i):
    dm = DEVMODEW(); dm.dmSize = ctypes.sizeof(DEVMODEW)
    return dm if user32.EnumDisplaySettingsW(None, wintypes.DWORD(i), ctypes.byref(dm)) else None

def _apply_hz(hz, w, h, bpp):
    dm = DEVMODEW(); dm.dmSize = ctypes.sizeof(DEVMODEW)
    dm.dmPelsWidth, dm.dmPelsHeight, dm.dmBitsPerPel, dm.dmDisplayFrequency = w, h, bpp, hz
    dm.dmFields = DM_BPP_W_H_HZ
    return user32.ChangeDisplaySettingsExW(None, ctypes.byref(dm), None, 0, None) == 0   # DISP_CHANGE_SUCCESSFUL

def set_refresh(target_hz_list):
    """Troca a tela principal para o 1º hz da lista disponível na resolução atual. Retorna (ok, msg).
    O Windows informa a frequência em Hz inteiros (47,952 aparece como 47 ou 48)."""
    cur = _mode(ENUM_CURRENT)
    if not cur: return False, "não consegui ler o modo atual da tela"
    w, h, bpp, cur_hz = cur.dmPelsWidth, cur.dmPelsHeight, cur.dmBitsPerPel, cur.dmDisplayFrequency
    disp = set(); i = 0
    while (m := _mode(i)) is not None:
        if (m.dmPelsWidth, m.dmPelsHeight) == (w, h): disp.add(m.dmDisplayFrequency)
        i += 1
    for hz in target_hz_list:
        achado = next((f for f in sorted(disp) if abs(f - hz) <= 1), None)
        if achado is None: continue
        if achado == cur_hz: return True, f"tela já em {cur_hz} Hz"
        st = json.loads(STATE.read_text(encoding="utf-8")) if STATE.exists() else {}
        st.update({"orig_hz": cur_hz, "orig_w": w, "orig_h": h, "orig_bpp": bpp})
        STATE.write_text(json.dumps(st), encoding="utf-8")
        if not _apply_hz(achado, w, h, bpp): return False, f"o driver recusou {achado} Hz em {w}x{h}"
        time.sleep(2); return True, f"tela {w}x{h} → {achado} Hz (era {cur_hz})"
    return False, (f"nenhum modo {target_hz_list} Hz em {w}x{h} (tela em {cur_hz} Hz; disponíveis: "
                   f"{', '.join(map(str, sorted(disp)))}) — crie 48 Hz no Painel NVIDIA (Alterar resolução › Personalizar), no AMD Adrenalin ou no CRU")

def restore_refresh():
    if not STATE.exists(): return
    st = json.loads(STATE.read_text(encoding="utf-8"))
    if "orig_hz" in st:
        _apply_hz(st["orig_hz"], st["orig_w"], st["orig_h"], st["orig_bpp"])
        log(f"tela restaurada para {st['orig_hz']} Hz")
        for k in ("orig_hz", "orig_w", "orig_h", "orig_bpp"): st.pop(k, None)
        STATE.write_text(json.dumps(st), encoding="utf-8")

# ---------------------------------------------------------------- janelas (EnumWindows)
def _exe_of(hwnd):
    pid = wintypes.DWORD(); user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    hp = kernel32.OpenProcess(0x1000, False, pid.value)          # PROCESS_QUERY_LIMITED_INFORMATION
    if not hp: return ""
    buf = ctypes.create_unicode_buffer(1024); n = wintypes.DWORD(1024)
    ok = kernel32.QueryFullProcessImageNameW(hp, 0, buf, ctypes.byref(n)); kernel32.CloseHandle(hp)
    return Path(buf.value).name if ok else ""

def windows_of(exes):
    """Janelas visíveis com título pertencentes a um dos executáveis: [(hwnd, título, classe, exe)]."""
    alvo = {e.lower() for e in exes}; res = []
    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd) and user32.GetWindowTextLengthW(hwnd) > 0:
            exe = _exe_of(hwnd)
            if exe.lower() in alvo:
                t = ctypes.create_unicode_buffer(512); user32.GetWindowTextW(hwnd, t, 512)
                c = ctypes.create_unicode_buffer(256); user32.GetClassNameW(hwnd, c, 256)
                res.append((hwnd, t.value, c.value, exe))
        return True
    user32.EnumWindows(cb, 0); return res

def obs_window_id(title, cls, exe):
    """Formato de janela do OBS no Windows: título:classe:exe, com ':' → '#3A' e '#' → '#22'."""
    enc = lambda s: s.replace("#", "#22").replace(":", "#3A")
    return f"{enc(title)}:{enc(cls)}:{enc(exe)}"

def open_whatsapp_maximized():
    exes = CFG["whatsapp_exe"]; exes = [exes] if isinstance(exes, str) else exes
    if not windows_of(exes):
        try: subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{CFG['whatsapp_aumid']}"])
        except Exception: os.startfile("whatsapp:")
    for _ in range(40):                                   # espera a janela existir
        w = windows_of(exes)
        if w: break
        time.sleep(0.5)
    else:
        return False, "WhatsApp não abriu janela (instalado pela Microsoft Store?)", None
    hwnd, title, cls, exe = w[0]
    user32.ShowWindow(hwnd, 3); user32.SetForegroundWindow(hwnd)   # SW_MAXIMIZE
    return True, f"WhatsApp aberto e maximizado ({exe})", (title, cls, exe)

# ---------------------------------------------------------------- OBS: arquivos de configuração
PROFILE = CFG.get("obs_profile", "Untitled"); COLLECTION = CFG.get("obs_collection", "Untitled")
SCENE = "Tela inteira"; SCENE_WA = "Chamada WhatsApp"; SRC_VIDEO = "WhatsApp (tela)"; SRC_WA_AUDIO = "WhatsApp (audio interlocutor)"; SRC_MIC = "Mic protagonista"

ENCODER_PRIORIDADE = ["obs_nvenc_h264_tex", "h264_texture_amf", "obs_qsv11_v2", "obs_x264"]

def obs_log_mais_novo(depois_de=0):
    """Log de inicialização mais recente do OBS (pasta logs do %APPDATA%/obs-studio), criado depois do instante dado."""
    try: logs = sorted((OBS_DIR / "logs").glob("*.txt"), key=lambda q: q.stat().st_mtime, reverse=True)
    except OSError: return None
    for q in logs:
        if q.stat().st_mtime >= depois_de - 5: return q
    return None

def obs_log_info(log_path):
    """Lê do log do OBS o adaptador gráfico em que ele subiu e os encoders de vídeo que carregou DE FATO
    (bloco "Available Encoders:" → "Video Encoders:"). Encoders vazio = bloco ainda não escrito."""
    try: txt = log_path.read_text(encoding="utf-8", errors="replace")
    except (OSError, AttributeError): return "", []
    m = re.search(r"Loading up D3D11 on adapter (.+?) \(\d+\)", txt)
    adaptador = m.group(1).strip() if m else ""
    m = re.search(r"Video Encoders:\n(.*?)Audio Encoders:", txt, re.S)
    encs = re.findall(r"^[\d:.]+\s*- (\S+) \(", m.group(1), re.M) if m else []
    return adaptador, encs

def encoder_do_log(log_path):
    """Melhor encoder H.264 entre os que o OBS carregou (NVENC > AMF > QuickSync > x264); None sem log/bloco."""
    adaptador, encs = obs_log_info(log_path)
    if not encs: return None
    return next((e for e in ENCODER_PRIORIDADE if e in encs), "obs_x264")

def pick_encoder():
    """H.264 por hardware, prioridade NVENC > AMF > QuickSync > x264.
    Decide pelo que o OBS carregou de verdade no último log — o OBS usa UM adaptador (o primeiro do Windows) e só
    os encoders dele existem: num PC com Radeon no slot 0 e GeForce no 1, o NVENC não carrega ("Encoder ID
    'obs_nvenc_h264_tex' not found") e a gravação nem começa — visto em 07/10/2026. Sem log (1ª vez), palpite
    pelas placas do registro; o PREPARAR confere de novo depois de abrir o OBS e troca se for preciso.
    NVENC vem antes do QuickSync porque máquinas com Quadro/GeForce costumam ter também a Intel UHD integrada."""
    enc = CFG.get("video_encoder", "auto")
    if enc != "auto": return enc
    real = encoder_do_log(obs_log_mais_novo())
    if real: return real
    g = " ".join(gpus()).lower()                  # ex.: "NVIDIA Quadro P4000, Intel(R) UHD Graphics 630"
    if "nvidia" in g: return "obs_nvenc_h264_tex"
    if "radeon" in g or "amd" in g: return "h264_texture_amf"
    if "intel" in g: return "obs_qsv11_v2"
    return "obs_x264"

def conferir_encoder(enc, aberto_em, espera=10):
    """Depois de abrir o OBS: lê o log novo e devolve (encoder que existe de fato, adaptador). Se o escolhido não
    carregou, devolve o melhor disponível. Espera o bloco de encoders aparecer no log (até `espera` s)."""
    t0 = time.time()
    while time.time() - t0 < espera:
        lg = obs_log_mais_novo(aberto_em)
        adaptador, encs = obs_log_info(lg) if lg else ("", [])
        if encs:
            if enc in encs or CFG.get("video_encoder", "auto") != "auto": return enc, adaptador
            return next((e for e in ENCODER_PRIORIDADE if e in encs), "obs_x264"), adaptador
        time.sleep(1)
    return enc, ""

def encoder_settings(enc):
    """High, qualidade máxima do preset, CQP fixo, keyframe a cada 1 s (24 frames), sem B-frames."""
    q = int(CFG.get("cqp", 14))
    if "amf" in enc:  return {"rate_control": "CQP", "cqp": q, "preset": "quality", "profile": "high", "keyint_sec": 1, "bf": 0}
    if "qsv" in enc:  return {"rate_control": "CQP", "cqp": q, "qpi": q, "qpp": q, "qpb": q, "target_usage": "TU1",
                              "profile": "high", "keyint_sec": 1, "bframes": 0}
    # NVENC: p5 = "Quality" do OBS (p7 é o mais lento e pode perder frames em Quadros mais antigos)
    if "nvenc" in enc: return {"rate_control": "CQP", "cqp": q, "preset2": "p5", "tune": "hq", "multipass": "disabled",
                               "profile": "high", "keyint_sec": 1, "bf": 0}
    return {"rate_control": "CRF", "crf": q, "preset": "veryfast", "profile": "high", "keyint_sec": 1, "x264opts": "bframes=0"}

def write_profile(rec_dir, enc):
    d = OBS_DIR / "basic/profiles" / PROFILE; d.mkdir(parents=True, exist_ok=True)
    ini = f"""[General]
Name={PROFILE}

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD_%hh-%mm-%ss_{CFG.get('suffix','WIN')}
DelayEnable=false
Reconnect=true

[AdvOut]
Encoder={enc}
RecType=Standard
RecFilePath={rec_dir}
RecFormat2=mov
RecUseRescale=false
RecTracks=15
RecEncoder={enc}
RecAudioEncoder={CFG.get('audio_encoder','ffmpeg_pcm_s24le')}
RecSplitFile=false
RecRB=false
AudioEncoder=ffmpeg_aac
Track1Bitrate=320
Track2Bitrate=320
Track3Bitrate=320
Track4Bitrate=320

[Video]
BaseCX={CFG.get('width',1920)}
BaseCY={CFG.get('height',1080)}
OutputCX={CFG.get('width',1920)}
OutputCY={CFG.get('height',1080)}
FPSType=2
FPSNum={CFG.get('fps_num',24000)}
FPSDen={CFG.get('fps_den',1001)}
ScaleType=lanczos
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo
"""
    (d / "basic.ini").write_text(ini, encoding="utf-8")
    (d / "recordEncoder.json").write_text(json.dumps(encoder_settings(enc)), encoding="utf-8")
    (d / "streamEncoder.json").unlink(missing_ok=True)

def write_websocket_cfg():
    d = OBS_DIR / "plugin_config/obs-websocket"; d.mkdir(parents=True, exist_ok=True)
    f = d / "config.json"
    cfg = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    cfg.update({"server_enabled": True, "server_port": CFG.get("ws_port", 4455),
                "auth_required": False, "alerts_enabled": False, "first_load": False})
    f.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

def write_user_ini():
    """Sem modo estúdio, sem confirmação ao sair, sem assistente de 1ª execução (user.ini no OBS 31+, global.ini antes)."""
    vals = (("PreviewProgramMode", "false"), ("ConfirmOnExit", "false"), ("FirstRun", "false"))
    existentes = [f for f in (OBS_DIR / "user.ini", OBS_DIR / "global.ini") if f.exists()]
    if not existentes:
        OBS_DIR.mkdir(parents=True, exist_ok=True)
        (OBS_DIR / "user.ini").write_text("[General]\nFirstRun=false\nConfirmOnExit=false\n\n[BasicWindow]\nPreviewProgramMode=false\n",
                                          encoding="utf-8-sig")
        return
    for f in existentes:
        t = f.read_text(encoding="utf-8-sig")
        for k, v in vals: t = re.sub(rf"^{k}=.*$", f"{k}={v}", t, flags=re.M)
        f.write_text(t, encoding="utf-8-sig")

def _src(id_, name, settings, mixers=255):
    return {"prev_ver": 537001986, "name": name, "uuid": str(uuid.uuid4()), "id": id_, "versioned_id": id_,
            "settings": settings, "mixers": mixers, "sync": 0, "flags": 0, "volume": 1.0, "balance": 0.5,
            "enabled": True, "muted": False, "push-to-mute": False, "push-to-mute-delay": 0,
            "push-to-talk": False, "push-to-talk-delay": 0,
            "hotkeys": {"libobs.mute": [], "libobs.unmute": [], "libobs.push-to-mute": [], "libobs.push-to-talk": []},
            "deinterlace_mode": 0, "deinterlace_field_order": 0, "monitoring_type": 0, "private_settings": {}}

def _item(s, i, w, h):
    return {"name": s["name"], "source_uuid": s["uuid"], "visible": True, "locked": False, "rot": 0.0,
            "scale_ref": {"x": float(w), "y": float(h)}, "pos": {"x": 0.0, "y": 0.0}, "scale": {"x": 1.0, "y": 1.0},
            "align": 5, "bounds_type": 2, "bounds_align": 0, "bounds_crop": False,
            "bounds": {"x": float(w), "y": float(h)}, "crop_left": 0, "crop_top": 0, "crop_right": 0, "crop_bottom": 0,
            "id": i, "group_item_backup": False, "scale_filter": "disable", "blend_method": "default",
            "blend_type": "normal", "show_transition": {"duration": 0}, "hide_transition": {"duration": 0},
            "private_settings": {}}

def _hk(n):  # Ctrl+Alt+1, Ctrl+Alt+2, Ctrl+Alt+3 para trocar de cena
    return {"OBSBasic.SelectScene": [{"key": f"OBS_KEY_{n}", "control": True, "alt": True}]}

def write_scene(wa_win=None):
    """wa_win = (título, classe, exe) da janela real do WhatsApp; a captura casa pelo executável (priority 2)."""
    w, h = CFG.get("width", 1920), CFG.get("height", 1080)
    wa = obs_window_id(*(wa_win or ("WhatsApp", "WinUIDesktopWin32WindowClass", "WhatsApp.Root.exe")))
    ch = obs_window_id("Google Chrome", "Chrome_WidgetWin_1", CFG.get("chrome_exe", "chrome.exe"))
    mic = _src("wasapi_input_capture", SRC_MIC, {"device_id": "default"}, mixers=5)               # pistas 1+3 (compartilhado)
    # cena 1: WhatsApp (janela via Windows Graphics Capture + áudio só do processo)
    v1 = _src("window_capture", SRC_VIDEO, {"window": wa, "priority": 2, "method": 2, "cursor": True, "client_area": True})
    a1 = _src("wasapi_process_output_capture", SRC_WA_AUDIO, {"window": wa, "priority": 2}, mixers=3)
    s1 = _src("scene", SCENE_WA, {"id_counter": 3, "custom_size": False, "items": [_item(v1, 1, w, h), _item(a1, 2, w, h), _item(mic, 3, w, h)]}); s1["hotkeys"] = _hk(2)
    # cena 2: Chrome (janela + áudio do Chrome — YouTube, Instagram etc.)
    v2 = _src("window_capture", "Chrome (tela)", {"window": ch, "priority": 2, "method": 2, "cursor": False, "client_area": True})
    a2 = _src("wasapi_process_output_capture", "Chrome (audio)", {"window": ch, "priority": 2}, mixers=3)
    s2 = _src("scene", "Chrome", {"id_counter": 3, "custom_size": False, "items": [_item(v2, 1, w, h), _item(a2, 2, w, h), _item(mic, 3, w, h)]}); s2["hotkeys"] = _hk(3)
    # cena 3: tela inteira (monitor principal + todo o áudio do sistema)
    v3 = _src("monitor_capture", "Monitor (video)", {"method": 0, "capture_cursor": True})
    a3 = _src("wasapi_output_capture", "Audio do sistema", {"device_id": "default"}, mixers=3)
    a4 = _src("wasapi_process_output_capture", "WhatsApp (audio pista 4)", {"window": wa, "priority": 2}, mixers=9)   # pistas 1+4
    s3 = _src("scene", "Tela inteira", {"id_counter": 4, "custom_size": False, "items": [_item(v3, 1, w, h), _item(a3, 2, w, h), _item(mic, 3, w, h), _item(a4, 4, w, h)]}); s3["hotkeys"] = _hk(1)
    doc = {"name": COLLECTION, "current_scene": SCENE, "current_program_scene": SCENE,
           "scene_order": [{"name": SCENE}, {"name": SCENE_WA}, {"name": "Chrome"}],
           "current_transition": "Cortar", "transition_duration": 0, "transitions": [], "saved_projectors": [],
           "groups": [], "modules": {"scripts-tool": [], "output-timer": {}},
           "sources": [mic, v1, a1, s1, v2, a2, s2, v3, a3, a4, s3]}
    d = OBS_DIR / "basic/scenes"; d.mkdir(parents=True, exist_ok=True)
    (d / f"{COLLECTION}.json").write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")

# ---------------------------------------------------------------- OBS via websocket
def obs_connect(timeout=40):
    import obsws_python as obs
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            return obs.ReqClient(host="localhost", port=CFG.get("ws_port", 4455), password="", timeout=5)
        except Exception:
            time.sleep(1)
    raise RuntimeError("OBS não respondeu no websocket (porta %s)" % CFG.get("ws_port", 4455))

def launch_obs():
    exe = Path(CFG["obs_exe"])
    if not exe.exists(): raise RuntimeError(f"OBS não encontrado em {exe} — rode o instalar.bat")
    # o OBS no Windows precisa rodar com a pasta do executável como diretório atual
    subprocess.Popen([str(exe), "--collection", COLLECTION, "--profile", PROFILE, "--scene", SCENE,
                      "--disable-updater", "--disable-shutdown-check"], cwd=str(exe.parent))
    return obs_connect()

def pick_mic(ws):
    """Escolhe o dispositivo de entrada: 1º que case com mic_hint; senão 1º que não seja padrão/virtual/embutido."""
    items = ws.get_input_properties_list_property_items(SRC_MIC, "device_id").property_items
    names = [(i["itemName"], i["itemValue"]) for i in items]
    hint = CFG.get("mic_hint", "").lower()
    bad = ("default", "padrão", "ndi", "teams", "zoom", "vb-", "virtual", "voicemeeter", "cable", "stereo mix", "mixagem estéreo",
           "iphone", "webcam", "realtek", "matriz de microfones", "microphone array", "intel® smart sound", "intel smart sound")
    chosen = None
    if hint: chosen = next(((n, v) for n, v in names if hint in n.lower()), None)
    if not chosen: chosen = next(((n, v) for n, v in names if v != "default" and not any(b in n.lower() for b in bad)), None)
    if chosen:
        ws.set_input_settings(SRC_MIC, {"device_id": chosen[1]}, True)
        return chosen[0], True
    return "microfone padrão do Windows (nenhuma interface USB encontrada)", False

def pick_monitor(ws, name="Monitor (video)"):
    """OBS 30+ identifica o monitor por monitor_id (string do dispositivo); escrito no JSON fica vazio.
    Escolhe o monitor principal (ou o 1º da lista) via websocket."""
    try:
        items = [i for i in ws.get_input_properties_list_property_items(name, "monitor_id").property_items
                 if i.get("itemEnabled", True) and i.get("itemValue")]
    except Exception as e:
        return None, f"monitor: erro ao listar ({e})"
    if not items: return None, "nenhum monitor listado pelo OBS"
    hint = CFG.get("monitor_hint", "").lower()
    chosen = (next((i for i in items if hint and hint in i["itemName"].lower()), None)
              or next((i for i in items if "principal" in i["itemName"].lower() or "primary" in i["itemName"].lower()), None)
              or items[0])
    ws.set_input_settings(name, {"monitor_id": chosen["itemValue"]}, True)
    return chosen["itemName"], None

def frame_brightness(ws):
    """Média de luminância do preview (0-255) usando ffmpeg signalstats; None se ffmpeg ausente."""
    if not shutil.which("ffmpeg"): return None
    r = ws.get_source_screenshot(ws.get_current_program_scene().current_program_scene_name, "png", 320, 180, -1)
    data = base64.b64decode(r.image_data.split(",", 1)[1])
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f: f.write(data); p = f.name
    out = sh(["ffmpeg", "-v", "info", "-i", p, "-vf", "signalstats,metadata=print:file=-", "-f", "null", "-"])
    os.unlink(p); m = re.search(r"YAVG=([\d.]+)", out)
    return float(m.group(1)) if m else None

# ---------------------------------------------------------------- fluxos
def preparar(quiet=False):
    """quiet=True (app de bandeja): sem janela quando está tudo OK — só o aviso perto do relógio."""
    rep = []; bad = []
    name, cpu = model_info(); gp = ", ".join(gpus()) or "?"; log(f"máquina: {name} ({cpu}) GPU: {gp}")
    rd = rec_path(); fg = free_gb(rd); rep.append(f"Pasta: {rd} — {fg:.0f} GB livres (~{fg/GB_POR_HORA:.1f} h de H.264)")
    if fg < CFG.get("min_free_gb", 50): bad.append(f"Pouco espaço: {fg:.0f} GB")
    if not on_ac(): bad.append("Na bateria — ligue o carregador")
    enc = pick_encoder(); rep.append(f"Encoder: {enc} (GPU: {gp})"); i_enc = len(rep) - 1
    quit_obs()
    if CFG.get("set_refresh", True):
        ok, msg = set_refresh(CFG.get("target_hz", [48])); rep.append("Tela: " + msg + ("" if ok else " (grava normalmente em 60 Hz)"))
    ok, msg, wa_win = open_whatsapp_maximized(); rep.append(msg); (None if ok else bad.append(msg))
    write_profile(rd, enc); write_websocket_cfg(); write_user_ini(); write_scene(wa_win); log("config OBS reescrita")
    time.sleep(2)                                          # WhatsApp aberto ANTES do OBS, como no macOS
    aberto_em = time.time(); ws = launch_obs(); time.sleep(3)
    # O OBS só tem os encoders do adaptador em que subiu: se o escolhido não existe, troca e reabre (1 vez)
    real, adaptador = conferir_encoder(enc, aberto_em)
    if real != enc:
        log(f"encoder {enc} não carregou no OBS (adaptador: {adaptador or '?'}) — trocando para {real}")
        quit_obs(); write_profile(rd, real); enc = real
        aberto_em = time.time(); ws = launch_obs(); time.sleep(3)
    rep[i_enc] = f"Encoder: {enc} (OBS no adaptador: {adaptador or gp})"
    if enc == "obs_x264": bad.append("Sem encoder por hardware no adaptador do OBS — usando x264 (CPU)")
    v = ws.get_video_settings(); fps = f"{v.fps_numerator}/{v.fps_denominator}"
    rep.append(f"OBS: {v.output_width}x{v.output_height} @ {fps} ({v.fps_numerator/v.fps_denominator:.3f} fps)")
    if (v.fps_numerator, v.fps_denominator) != (CFG.get("fps_num", 24000), CFG.get("fps_den", 1001)): bad.append("FPS errado no OBS")
    mon, err = pick_monitor(ws); rep.append(f"Monitor: {mon}") if mon else bad.append("Tela inteira sem monitor: " + err)
    mic, is_usb = pick_mic(ws); rep.append(f"Mic: {mic}"); (None if is_usb else bad.append("Mic USB não encontrado — usando o padrão"))
    time.sleep(2); y = frame_brightness(ws)
    if y is None: rep.append("Vídeo: (ffmpeg ausente, sem checagem de tela preta)")
    elif y < 8: bad.append(f"Captura PRETA na cena ativa (Y={y:.0f}) — confira a fonte e rode PREPARAR de novo")
    else: rep.append(f"Vídeo: captura OK (Y={y:.0f})")
    rd2 = ws.get_record_directory().record_directory; rep.append(f"Grava em: {rd2}")
    st = json.loads(STATE.read_text(encoding="utf-8")) if STATE.exists() else {}; st["prepared_at"] = time.time()
    STATE.write_text(json.dumps(st), encoding="utf-8")
    txt = "\n".join(rep) + ("\n\nATENÇÃO:\n- " + "\n- ".join(bad) if bad else "\n\nTUDO PRONTO. Clique GRAVAR quando a chamada começar.")
    log(txt.replace("\n", " | "))
    if quiet and not bad: notify("Gravar Doc — PRONTO", "Clique no botão vermelho GRAVAR.")
    else: notify("Gravar Doc", "PRONTO" if not bad else f"{len(bad)} alerta(s)"); dialog("Gravar Doc — PREPARAR", txt, ok=not bad)
    return not bad

def pronto():
    """True se o OBS já está aberto com a configuração do Gravar Doc (websocket responde e a coleção é a nossa)."""
    if not obs_running(): return False
    try:
        import obsws_python as obs
        c = obs.ReqClient(host="localhost", port=CFG.get("ws_port", 4455), password="", timeout=2)
        return c.get_scene_collection_list().current_scene_collection_name == COLLECTION
    except Exception:
        return False

def gravando():
    try:
        import obsws_python as obs
        return obs.ReqClient(host="localhost", port=CFG.get("ws_port", 4455), password="", timeout=2).get_record_status().output_active
    except Exception:
        return False

def verify_file(path):
    if not shutil.which("ffprobe"): return f"Arquivo: {path}"
    js = json.loads(sh(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path]))
    v = next(s for s in js["streams"] if s["codec_type"] == "video"); a = [s for s in js["streams"] if s["codec_type"] == "audio"]
    dur = float(js["format"].get("duration", 0)); nb = int(v.get("nb_frames", 0) or 0)
    exp = dur * CFG.get("fps_num", 24000) / CFG.get("fps_den", 1001)
    info = f"{Path(path).name}\n{v['codec_name']} {v.get('profile','')} {v['width']}x{v['height']} {v['r_frame_rate']} — {dur/60:.1f} min\n"
    info += f"{len(a)} pistas de áudio ({a[0]['codec_name']} {a[0]['sample_rate']} Hz)" if a else "SEM ÁUDIO"
    n_exp = CFG.get("audio_tracks", 4)
    if len(a) != n_exp: info += f"\nALERTA: {len(a)} pistas de áudio, esperado {n_exp}"
    if nb and abs(nb - exp) > exp * 0.01: info += f"\nALERTA: {nb} frames, esperado ~{exp:.0f}"
    if v["r_frame_rate"] != f"{CFG.get('fps_num',24000)}/{CFG.get('fps_den',1001)}": info += "\nALERTA: fps do arquivo diferente de 23,976"
    return info

def gravar(quiet=False):
    ws = obs_connect(timeout=8)
    if not ws.get_record_status().output_active:
        ws.start_record(); time.sleep(1.5)
        if not ws.get_record_status().output_active: dialog("Gravar Doc", "Falha ao iniciar a gravação — veja o OBS", ok=False); return
        notify("Gravar Doc", "GRAVANDO ● — clique PARAR para terminar"); log("gravação iniciada")
    else:
        path = ws.stop_record().output_path; log(f"parada: {path}")
        for _ in range(20):
            if Path(path).exists() and not ws.get_record_status().output_active: break
            time.sleep(0.5)
        time.sleep(1); info = verify_file(path); restore_refresh()
        log(info.replace("\n", " | "))
        if "ALERTA" in info or not quiet: dialog("Gravar Doc — PARADO", info, ok="ALERTA" not in info)
        else: notify("Gravar Doc — SALVO", Path(path).name)

def status():
    ws = obs_connect(timeout=5); r = ws.get_record_status(); v = ws.get_video_settings()
    print(f"gravando={r.output_active} tempo={r.output_timecode} fps={v.fps_numerator}/{v.fps_denominator}")

def diagnostico():
    """Sem OBS e sem licença: mostra o que o PREPARAR vai encontrar nesta máquina (para testar o ambiente)."""
    name, cpu = model_info(); print(f"máquina: {name} | CPU: {cpu}"); print(f"GPU: {', '.join(gpus()) or '?'} → encoder {pick_encoder()}")
    lg = obs_log_mais_novo(); adaptador, encs = obs_log_info(lg) if lg else ("", [])
    print(f"OBS (último log {lg.name if lg else '—'}): adaptador {adaptador or '?'} | encoders: {', '.join(encs) or '?'}")
    cur = _mode(ENUM_CURRENT); print(f"tela: {cur.dmPelsWidth}x{cur.dmPelsHeight} @ {cur.dmDisplayFrequency} Hz" if cur else "tela: ?")
    rd = rec_path(); print(f"pasta: {rd} — {free_gb(rd):.0f} GB livres | tomada: {on_ac()}")
    print(f"OBS: {'ok' if Path(CFG['obs_exe']).exists() else 'NÃO instalado'} ({CFG['obs_exe']}) | rodando: {obs_running()}")
    print(f"ffmpeg: {shutil.which('ffmpeg') or 'NÃO encontrado'}")
    exes = CFG["whatsapp_exe"]; w = windows_of([exes] if isinstance(exes, str) else exes)
    print(f"WhatsApp: {obs_window_id(*w[0][1:]) if w else 'sem janela aberta'}")
    ok, msg, _ = licenca.verificar(); print(("licença OK: " if ok else "licença BLOQUEADA: ") + msg); print("ID:", licenca.id_maquina())

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "preparar"
    if cmd == "diagnostico": diagnostico(); sys.exit(0)
    try:
        log(licenca.exigir(dialog))            # bloqueia sem licença válida da V-Engine
        {"preparar": preparar, "gravar": gravar, "status": status}[cmd]()
    except SystemExit: raise
    except Exception as e:
        log(f"ERRO: {e!r}"); dialog("Gravar Doc — ERRO", str(e), ok=False); sys.exit(1)
