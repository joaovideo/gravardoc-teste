#!/bin/zsh
# =====================================================================================
#  Gravar Doc — instalador macOS
#  © 2026 V-Engine / VENG Projetos e Tecnologia Ltda. Todos os direitos reservados.
#  Verifica e instala (com permissão) tudo o que o app precisa, recria o venv e os apps.
# =====================================================================================
cd "$(dirname "$0")"
APPDIR="$(pwd)"
set -e

ok()   { print -P "%F{green}✔%f $1"; }
warn() { print -P "%F{yellow}!%f $1"; }
fail() { print -P "%F{red}✘ $1%f"; osascript -e "display dialog \"$1\" with title \"Gravar Doc — Instalação\" buttons {\"OK\"} with icon stop" >/dev/null 2>&1; exit 1; }

# Pergunta ao usuário (diálogo do macOS). Retorna 0 se ele autorizar.
perguntar() {
  osascript -e "button returned of (display dialog \"$1\" with title \"Gravar Doc — Instalação\" buttons {\"Agora não\", \"Instalar\"} default button \"Instalar\" with icon caution)" 2>/dev/null | grep -q "Instalar"
}

echo "== Gravar Doc: instalação =="
[[ "$(uname -m)" == "arm64" ]] || warn "Mac Intel detectado — o app foi feito para Apple Silicon (ProRes por hardware)."

# ---------------------------------------------------------------- 1. Homebrew
if [[ -x /opt/homebrew/bin/brew ]]; then eval "$(/opt/homebrew/bin/brew shellenv)"
elif [[ -x /usr/local/bin/brew ]];  then eval "$(/usr/local/bin/brew shellenv)"; fi

if ! command -v brew >/dev/null; then
  perguntar "O Homebrew não está instalado.\n\nEle é o gerenciador de pacotes usado para instalar ffmpeg e displayplacer. A instalação é oficial (brew.sh), leva alguns minutos e vai pedir a SENHA de administrador do Mac nesta janela do Terminal.\n\nInstalar agora?" \
    || fail "Instalação cancelada: o Homebrew é necessário."
  echo "Instalando Homebrew (siga as instruções e digite a senha do Mac quando pedir)…"
  NONINTERACTIVE=0 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" \
    || fail "Falha ao instalar o Homebrew."
  eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null || /usr/local/bin/brew shellenv)"
  grep -q 'brew shellenv' ~/.zprofile 2>/dev/null || echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
fi
ok "Homebrew $(brew --version | head -1 | awk '{print $2}')"

# ---------------------------------------------------------------- 2. ferramentas de linha de comando
FALTAM=()
for f in python@3.12 ffmpeg displayplacer; do
  case $f in
    python@3.12) command -v python3 >/dev/null && python3 -c 'import sys; exit(sys.version_info < (3,11))' 2>/dev/null || FALTAM+=($f) ;;
    *) command -v $f >/dev/null || FALTAM+=($f) ;;
  esac
done
if (( ${#FALTAM} )); then
  echo "Instalando pelo Homebrew (sem perguntar): ${FALTAM[*]}"
  brew install ${FALTAM[@]} || fail "Falha ao instalar: ${FALTAM[*]}"
fi
ok "Python $(python3 --version | awk '{print $2}'), ffmpeg, displayplacer"

# ---------------------------------------------------------------- 3. aplicativos (OBS obrigatório; WhatsApp e Chrome recomendados)
instalar_app() {   # $1 = .app  $2 = cask  $3 = nome  $4 = obrigatorio(1/0)
  [[ -d "/Applications/$1" ]] && { ok "$3"; return; }
  echo "Instalando $3 pelo Homebrew (sem perguntar)…"
  if brew install --cask "$2"; then ok "$3 instalado"
  elif [[ "$4" == 1 ]]; then fail "Falha ao instalar $3 (necessário)."
  else warn "$3 não instalado — a cena correspondente ficará vazia."; fi
}
instalar_app "OBS.app"            obs            "OBS Studio"      1
instalar_app "WhatsApp.app"       whatsapp       "WhatsApp"        0
instalar_app "Google Chrome.app"  google-chrome  "Google Chrome"   0

OBSV=$(defaults read /Applications/OBS.app/Contents/Info.plist CFBundleShortVersionString 2>/dev/null || echo 0)
[[ "${OBSV%%.*}" -ge 32 ]] || warn "OBS $OBSV — recomendado 32.2 ou superior (brew upgrade --cask obs)."

# ---------------------------------------------------------------- 4. ambiente Python e apps clicáveis
rm -rf venv && python3 -m venv venv && ./venv/bin/pip -q install --upgrade pip && ./venv/bin/pip -q install -r requirements.txt
ok "Ambiente Python (obsws-python, cryptography)"

for a in "1 PREPARAR:preparar" "2 GRAVAR-PARAR:gravar"; do
  name="${a%%:*}"; cmd="${a##*:}"; rm -rf "$name.app"
  osacompile -o "$name.app" -e "do shell script \"cd '$APPDIR' && ./venv/bin/python gravar_doc.py $cmd >> run.log 2>&1\""
done
./venv/bin/python -m py_compile gravar_doc.py licenca.py
ok "Apps '1 PREPARAR' e '2 GRAVAR-PARAR' criados em $APPDIR"

# ---------------------------------------------------------------- 5. próximos passos
[[ -f licenca.json ]] && ok "Licença encontrada" || warn "Sem licenca.json — o PREPARAR vai mostrar o ID desta máquina para solicitar a licença à V-Engine."
echo ""
echo "Próximos passos:"
echo "  1. Abra o OBS uma vez e conceda Gravação de Tela e Microfone."
echo "  2. Clique em '1 PREPARAR'. Na 1ª vez, aprove Acessibilidade para '1 PREPARAR'"
echo "     em Ajustes > Privacidade e Segurança > Acessibilidade."
osascript -e 'display notification "Instalação concluída" with title "Gravar Doc"' >/dev/null 2>&1 || true
