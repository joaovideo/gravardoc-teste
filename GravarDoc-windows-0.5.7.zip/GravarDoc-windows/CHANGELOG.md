# Changelog

## 0.5.7 — 2026-10-07 (Windows)
- `instalar.ps1`: falha ao instalar um app **opcional** (WhatsApp, Chrome) vira aviso e a instalação segue — antes abortava tudo. O WhatsApp vem da Microsoft Store pelo winget e pode demorar ou travar; o instalador avisa e diz o que fazer.

## 0.5.6 — 2026-10-07
- **Um `licenca.json` ruim não bloqueia mais a versão free**: licença vencida, de outra máquina ou adulterada no disco passa a ser ignorada (motivo no log) e valem os 30 dias livres; um `licenca.json` válido continua tendo prioridade. Em 07/10 um `licenca.json` antigo copiado junto com o app travou a instalação pedindo licença.

## 0.5.5 — 2026-10-07 (Windows)
- **Atalho de teclado global** = GRAVAR / PARAR, igual ao botão: Ctrl+Alt+G, ou o primeiro livre entre Ctrl+Alt+R, Ctrl+Alt+F9 e Ctrl+Shift+F9 (no PC de teste o Ctrl+Alt+G já era de outro programa). O painel mostra qual valeu. Serve para parar a gravação por acesso remoto (TeamViewer, Remote Engine), quando o painel está invisível para a captura.

## 0.5.4 — 2026-10-07 (Windows)
- **Painel visível fora da gravação**: o botão GRAVAR/PARAR só fica invisível para capturas de tela enquanto grava. Esconder sempre (desde a 0.5.1) fazia o painel sumir também em acesso remoto (TeamViewer, Remote Engine): quem operava o PC de longe abria o app e "não aparecia nada". Nova opção `painel_na_captura: true` no `config.json` para nunca esconder (operador remoto precisa ver o PARAR; o botão então sai no vídeo).

## 0.5.3 — 2026-10-07 (Windows)
- **Encoder conferido no OBS de verdade**: o PREPARAR lê o log de inicialização do OBS e usa o encoder H.264 que ele carregou (NVENC > AMF > QuickSync > x264). O OBS só enxerga os encoders do adaptador gráfico em que subiu (o primeiro do Windows): num PC com Radeon RX 580 no slot 0 e GeForce no 1, o `obs_nvenc_h264_tex` não existia ("Encoder ID not found") e a gravação nem começava — a pasta de gravações ficava vazia. Agora troca sozinho (reescreve o perfil e reabre o OBS uma vez) e o relatório mostra o adaptador em uso. `diagnostico` lista os encoders do último log do OBS.

## 0.5.2 — 2026-10-06
- **Versão free de 30 dias**: uso livre por 30 dias a partir do 1º uso em cada máquina (data guardada em dois lugares; relógio atrasado é bloqueado). Depois, só com `licenca.json` assinado pela V‑Engine, que no Windows pode ser importado direto no aviso de expiração. O painel mostra os dias restantes.

## 0.5.1 — 2026-10-06 (Windows: um botão só)
- **Painel de um botão** no lugar do ícone de bandeja (o Windows 11 esconde ícones novos na setinha ^): dois cliques em "Gravar Doc" → tela de abertura → prepara sozinho (WhatsApp + OBS) → janelinha no canto inferior direito com **● GRAVAR / ■ PARAR**, sempre por cima e sem minimizar.
- O painel é **invisível para o OBS** (`SetWindowDisplayAffinity` WDA_EXCLUDEFROMCAPTURE): o operador vê, a gravação "Tela inteira" não.
- Se o OBS não estiver pronto ao clicar GRAVAR, prepara antes e já começa a gravar. Sem janelas quando está tudo OK (só aviso do Windows); diálogo só com alerta.
- Monitor sem 48 Hz deixou de ser alerta (grava normalmente em 60 Hz).
- Abrir de novo com uma versão antiga travada ou escondida na bandeja: encerra a antiga e segue.
- `instalar.ps1` cria só o atalho "Gravar Doc" e apaga os antigos "1 PREPARAR" / "2 GRAVAR-PARAR".
- Removido o pystray (a mistura bandeja + janela travava a janela após o primeiro clique).

## 0.5.0 — não lançado (Windows, em teste)
- **Versão Windows 11**: `gravar_doc_win.py` com o mesmo fluxo Preparar / Gravar‑Parar do macOS — H.264 por hardware escolhido pela GPU com prioridade NVENC > AMF > QuickSync > x264 (mesmos parâmetros para todos: High, CQP 14, keyframe 1 s, sem B‑frames), MOV com 3 pistas PCM 24‑bit, cenas WhatsApp / Chrome / Tela inteira com captura WGC e áudio por processo, 48 Hz via `ChangeDisplaySettingsEx`.
- `instalar.bat` / `instalar.ps1`: instala dependências via winget com permissão e cria os atalhos `1 PREPARAR` e `2 GRAVAR-PARAR`.
- `gravar_doc_win.py diagnostico`: mostra GPU, encoder, tela, disco, OBS, ffmpeg, WhatsApp e licença sem gravar nada.
- **App de bandeja** `app_gravardoc_win.py` (pystray): Preparar, Gravar/Parar (também com duplo clique no ícone), Importar licença…, Copiar ID, Abrir pasta de gravações, Sobre, Sair; ícone muda para ocupado/gravando; uma instância só; Preparar e Gravar desativados sem licença.
- **Tela de abertura** `splash_win.py` (tkinter) com o mesmo conteúdo e visual do `splash.py`.
- `build_win.bat`: compila com Nuitka (standalone, sem console, ícone e metadados V‑Engine/VENG) e gera `dist\GravarDoc-win.zip`, conferindo que não há `.py` nem chave privada no pacote.
- `licenca.py`: no Windows a licença fica em `%APPDATA%\GravarDoc`; aceita `licenca.json` com BOM (salvo pelo Bloco de Notas/PowerShell), que antes era recusado como inválido.
- ffmpeg instalado pelo winget é encontrado mesmo quando o PATH do processo está desatualizado (conta sem privilégio de symlink).
- `instalar.ps1 -Sim`: instalação sem supervisão; mensagem clara quando o UAC é recusado.
- 2026-10-06 — testado em PC Windows com NVIDIA GTX 1070 (OBS 32.2.2): Preparar e Gravar/Parar OK, MOV H.264 NVENC 1920x1080 24000/1001 com 4 pistas PCM 24‑bit. Corrigido: cena "Tela inteira" preta (o OBS 30+ usa `monitor_id`, agora escolhido via websocket); alerta falso de "4 pistas, esperado 3"; dica de 48 Hz cita o Painel NVIDIA.
- Pendente: chamada real no WhatsApp (pista 4), 48 Hz com resolução personalizada, encoders AMF/QuickSync.

## 0.4.0 — 2026-09-29
- **App empacotado**: `Gravar Doc.app` de barra de menus (Preparar, Gravar/Parar, Importar licença, Copiar ID, Abrir gravações, Sobre), compilado em binário nativo com Nuitka (`build_mac.sh`) — sem código-fonte Python no pacote.
- **Tela de abertura** com marca V-Engine/VENG, copyright, titular da licença e divulgação dos serviços VENG; rodapé de copyright em todos os diálogos.
- Licença, configuração, estado e log movidos para `~/Library/Application Support/GravarDoc` (migração automática).
- Sem licença para a máquina, Preparar e Gravar ficam desabilitados e o app mostra o ID de hardware.

## 0.3.1 — 2026-09-29
- `instalar.command` verifica Homebrew, Python, ffmpeg, displayplacer, OBS, WhatsApp e Chrome e oferece instalar o que faltar, com diálogo de permissão.

## 0.3.0 — 2026-09-29
- Aviso de propriedade intelectual V‑Engine/VENG no código e `LICENCA.txt` (Lei 9.609/1998).
- Licenciamento local: `licenca.py` verifica `licenca.json` assinado (Ed25519) e vinculado ao ID de hardware; `gerador/gerar_licenca.py` emite licenças.
- Testado: sem licença (bloqueia), licença válida (libera), adulterada (bloqueia), outra máquina (bloqueia).

## 0.2.0 — 2026-09-29
- Três cenas: Chamada WhatsApp (⌃⌥1), Chrome (⌃⌥2), Tela inteira (⌃⌥3), com áudio por aplicativo/sistema.
- Projeto renomeado para "Netflix": pasta de gravação `~/Movies/Netflix`.

## 0.1.0 — 2026-09-29
- Apps "1 PREPARAR" e "2 GRAVAR‑PARAR"; template do OBS (ProRes 422 HW, 24000/1001, 3 pistas PCM 24‑bit).
- Refresh 47,95 Hz automático no MacBook Pro via `displayplacer`, com restauração ao parar.
- Detecção de microfone USB, checagem de tela preta, validação do arquivo com `ffprobe`.
- Testado no MacBook Air M5 (macOS 27, OBS 32.2.2).
