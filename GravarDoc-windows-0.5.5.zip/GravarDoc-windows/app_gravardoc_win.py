# -*- coding: utf-8 -*-
# =====================================================================================
#  Gravar Doc — painel de um botão (Windows)
#  © 2026 V-Engine, divisão de desenvolvimento de software da VENG Projetos e Tecnologia Ltda.
#  Todos os direitos reservados. Software proprietário.
#
#  Uso: dois cliques em "Gravar Doc" na Área de Trabalho.
#    1. Abre a tela de abertura e prepara tudo sozinho (WhatsApp + OBS configurado).
#    2. Aparece uma janelinha no canto da tela com UM botão: ● GRAVAR / ■ PARAR.
#  Sem ícone de bandeja (o Windows 11 esconde esses ícones). Toda operação lenta roda
#  em thread; a janela (Tk) só é tocada pela thread principal.
# =====================================================================================
import os, queue, sys, threading, time
from pathlib import Path

VERSAO = "0.5.5"

# Modo linha de comando (testes/automação): app_gravardoc_win.py --cli preparar|gravar|status|diagnostico|licenca
if len(sys.argv) >= 3 and sys.argv[1] == "--cli":
    import gravar_doc_win, licenca
    cmd = sys.argv[2]
    if cmd == "licenca":
        ok, msg, _ = licenca.verificar(); print(("OK " if ok else "BLOQUEADO ") + msg); print("ID:", licenca.id_maquina()); sys.exit(0 if ok else 2)
    if cmd == "diagnostico": gravar_doc_win.diagnostico(); sys.exit(0)
    licenca.exigir(gravar_doc_win.dialog)
    {"preparar": gravar_doc_win.preparar, "gravar": gravar_doc_win.gravar, "status": gravar_doc_win.status}[cmd](); sys.exit(0)

import ctypes
from ctypes import wintypes
import tkinter as tk

TITULO = "Gravar Doc"
u32 = ctypes.windll.user32; k32 = ctypes.windll.kernel32

# ---------------------------------------------------------------- uma instância só
# Se já houver uma aberta: traz o painel para a frente. Se for versão antiga sem painel
# (só ícone escondido na bandeja), encerra a antiga e segue.
def _mutex_novo():
    m = k32.CreateMutexW(None, False, "Global\\VEngine.GravarDoc")
    return m, k32.GetLastError() == 183                       # ERROR_ALREADY_EXISTS

_mutex, _existe = _mutex_novo()
if _existe:
    h = u32.FindWindowW(None, TITULO)
    _r = ctypes.c_size_t(0)
    vivo = h and u32.SendMessageTimeoutW(h, 0, 0, 0, 0x2, 2000, ctypes.byref(_r))   # WM_NULL, SMTO_ABORTIFHUNG
    # só reaproveita se for o painel novo (janela de ferramenta) e estiver respondendo
    if vivo and (u32.GetWindowLongW(h, -20) & 0x80):                               # GWL_EXSTYLE & WS_EX_TOOLWINDOW
        u32.ShowWindow(h, 9); u32.SetForegroundWindow(h); sys.exit(0)
    import subprocess
    # exclui este processo e o pai (o pythonw do venv é um lançador que segura o interpretador real)
    ps = ("$me = Get-CimInstance Win32_Process -Filter 'ProcessId=%d'; $skip = @(%d, $me.ParentProcessId); "
          "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*app_gravardoc_win.py*' -and $skip -notcontains $_.ProcessId } "
          "| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" % (os.getpid(), os.getpid()))
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], creationflags=0x08000000, timeout=30)
    k32.CloseHandle(_mutex); time.sleep(1)
    _mutex, _existe = _mutex_novo()
    if _existe:
        u32.MessageBoxW(None, "O Gravar Doc já está aberto.", TITULO, 0x40); sys.exit(0)

import licenca
import gravar_doc_win as gd

VERMELHO, CINZA, FUNDO, TEXTO = "#c62828", "#424242", "#1e1e1e", "#dddddd"

class Painel:
    def __init__(self):
        self.ocupado = False          # preparando / parando (botão desativado)
        self.gravando = False
        self.msg = "Abrindo…"
        self._ws = None
        r = self.root = tk.Tk(); r.withdraw()
        r.title(TITULO); r.configure(bg=FUNDO); r.resizable(False, False)
        r.attributes("-topmost", True); r.attributes("-toolwindow", True)   # sem minimizar/maximizar
        r.protocol("WM_DELETE_WINDOW", self.fechar)
        self.lbl = tk.Label(r, text=self.msg, fg=TEXTO, bg=FUNDO, font=("Segoe UI", 11))
        self.lbl.pack(padx=14, pady=(10, 4))
        self.btn = tk.Button(r, text="●  GRAVAR", font=("Segoe UI", 20, "bold"), width=12, relief="flat",
                             fg="white", bg=VERMELHO, activebackground="#8e0000", activeforeground="white",
                             disabledforeground="#bbbbbb", command=self.clique)
        self.btn.pack(padx=14, pady=(0, 6))
        self.lbl_lic = tk.Label(r, text="", fg="#9e9e9e", bg=FUNDO, font=("Segoe UI", 8))
        self.lbl_lic.pack(padx=14)
        self.lbl_tecla = tk.Label(r, text="", fg="#9e9e9e", bg=FUNDO, font=("Segoe UI", 8)); self.lbl_tecla.pack(padx=14)
        rod = tk.Frame(r, bg=FUNDO); rod.pack(fill="x", padx=14, pady=(0, 8))
        for txt, cmd in (("abrir gravações", self.abrir_pasta), ("preparar de novo", self.preparar_de_novo)):
            l = tk.Label(rod, text=txt, fg="#8ab4f8", bg=FUNDO, font=("Segoe UI", 9, "underline"), cursor="hand2")
            l.pack(side="left" if txt.startswith("abrir") else "right"); l.bind("<Button-1>", lambda _e, c=cmd: c())
        r.after(300, self.splash)

    # ------------------------------------------------------------ janela (só thread principal)
    def splash(self):
        try:
            import splash_win
            ok, m, d = licenca.verificar()
            txt = m if ok else "Versão expirada — sem licença para esta máquina"
            splash_win.mostrar(VERSAO, txt, 4.0, root=self.root)
        except Exception as e:
            gd.log(f"splash: {e!r}")
        self.root.after(4200, self.mostrar)

    # ------------------------------------------------------------ licença / versão free (30 dias)
    def _licenca_ok(self):
        """True se pode usar. Se expirou: explica, oferece importar licenca.json e fecha se não houver."""
        ok, m, d = licenca.verificar()
        if ok:
            self.lbl_lic.config(text=m if not licenca.Path(licenca.ARQUIVO).exists() else f"Licenciado: {d.get('licenciado')}")
            return True
        import splash_win
        def importar():
            from tkinter import filedialog; import shutil
            c = filedialog.askopenfilename(parent=self.root, title="Selecione o licenca.json enviado pela VENG",
                                           filetypes=[("Licença", "*.json")])
            if not c: return False
            ok2, m2, _ = licenca.verificar(c)
            if not ok2:
                u32.MessageBoxW(None, f"Licença não aceita: {m2}", TITULO, 0x10 | 0x40000); return False
            licenca.ARQUIVO.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(c, licenca.ARQUIVO)
            u32.MessageBoxW(None, f"Licença ativada.\n{m2}", TITULO, 0x40 | 0x40000); return True
        gd.log(f"licença: {m}")
        if splash_win.expirado(VERSAO, m, licenca.id_maquina(), self.root, importar):
            return self._licenca_ok()
        return False

    def mostrar(self):
        if not self._licenca_ok(): self.root.destroy(); return
        r = self.root; r.update_idletasks()
        sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        r.geometry(f"+{sw - r.winfo_reqwidth() - 24}+{sh - r.winfo_reqheight() - 90}")
        r.deiconify(); r.lift()
        self._afinidade = None; self._afinar()
        threading.Thread(target=self._vigiar, daemon=True).start()
        threading.Thread(target=self._hotkey, daemon=True).start()
        self._em_thread(self._auto_preparar)
        self._redesenhar()

    # ------------------------------------------------------------ atalho global
    # Candidatos em ordem: o 1º livre é registrado e aparece no painel. Ctrl+Alt+G e Ctrl+Shift+G já estavam
    # ocupados no PC de teste (Radeon Software / TeamViewer), por isso a lista.
    ATALHOS = (("Ctrl+Alt+G", 0x2 | 0x1, 0x47), ("Ctrl+Alt+R", 0x2 | 0x1, 0x52),
               ("Ctrl+Alt+F9", 0x2 | 0x1, 0x78), ("Ctrl+Shift+F9", 0x2 | 0x4, 0x78))

    def _hotkey(self):
        """Atalho global = mesmo que clicar no botão. Existe porque, enquanto grava, o painel some das capturas (e
        portanto do TeamViewer / Remote Engine): o operador remoto para a gravação pelo teclado sem ver o botão.
        RegisterHotKey/GetMessage precisam ficar na MESMA thread; o clique vai para a thread do Tk via after()."""
        MOD_NOREPEAT, WM_HOTKEY = 0x4000, 0x0312
        nome = None
        for n, mods, vk in self.ATALHOS:
            if u32.RegisterHotKey(None, 1, mods | MOD_NOREPEAT, vk): nome = n; break
            gd.log(f"atalho {n} indisponível (já usado por outro programa)")
        if not nome:
            self.root.after(0, lambda: self.lbl_tecla.config(text="(sem atalho de teclado livre)")); return
        gd.log(f"atalho global: {nome}")
        self.root.after(0, lambda: self.lbl_tecla.config(text=f"{nome} = GRAVAR / PARAR"))
        msg = wintypes.MSG()
        while u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == WM_HOTKEY and msg.wParam == 1:
                gd.log(f"atalho {nome}"); self.root.after(0, self.clique)

    # ------------------------------------------------------------ visível para quem?
    def _afinar(self):
        """Esconde o painel das capturas de tela (WDA_EXCLUDEFROMCAPTURE, Windows 10 2004+) SÓ enquanto grava:
        o vídeo "Tela inteira" sai limpo e, fora da gravação, o painel aparece normalmente. Esconder sempre
        (0.5.1–0.5.3) tornava o botão invisível também em acesso remoto (TeamViewer, Remote Engine…) — o operador
        remoto abria o app e "não aparecia nada" (07/10/2026). `painel_na_captura: true` no config.json nunca
        esconde (quem grava por acesso remoto precisa ver o PARAR; o botão então sai no vídeo)."""
        esconder = bool(self.gravando) and not gd.CFG.get("painel_na_captura", False)
        if esconder == self._afinidade: return
        try:
            hwnd = int(self.root.wm_frame(), 16)
            if u32.SetWindowDisplayAffinity(hwnd, 0x11 if esconder else 0): self._afinidade = esconder
            else: gd.log("painel: SetWindowDisplayAffinity falhou")
        except Exception as e:
            gd.log(f"painel: affinity {e!r}")

    def _redesenhar(self):
        r = self.root
        if r.state() != "normal": r.deiconify()                       # nunca some
        self._afinar()
        if self.ocupado:     txt, cor, st = "aguarde…", "#555555", "disabled"
        elif self.gravando:  txt, cor, st = "■  PARAR", CINZA, "normal"
        else:                txt, cor, st = "●  GRAVAR", VERMELHO, "normal"
        self.btn.config(text=txt, bg=cor, state=st)
        self.lbl.config(text="●  GRAVANDO" if self.gravando and not self.ocupado else self.msg,
                        fg="#ff5252" if self.gravando else TEXTO)
        r.after(300, self._redesenhar)

    def fechar(self):
        if self.gravando:
            u32.MessageBoxW(None, "Está GRAVANDO. Clique PARAR antes de fechar.", TITULO, 0x30 | 0x40000); return
        self.root.destroy()

    # ------------------------------------------------------------ ações (rodam em thread)
    def _em_thread(self, fn):
        if self.ocupado: return
        self.ocupado = True
        def job():
            try: fn()
            except SystemExit: pass
            except Exception as e:
                gd.log(f"ERRO: {e!r}"); self.msg = "Erro — veja o aviso"; gd.dialog("Gravar Doc — ERRO", str(e), ok=False)
            finally:
                self.ocupado = False
        threading.Thread(target=job, daemon=True).start()

    def _auto_preparar(self):
        if gd.pronto(): self.msg = "Pronto"; return
        self.msg = "Preparando… (~30 s)"
        self.msg = "Pronto" if gd.preparar(quiet=True) else "Pronto (com alertas)"

    def preparar_de_novo(self):
        if self.gravando: return
        def f():
            self.msg = "Preparando… (~30 s)"
            self.msg = "Pronto" if gd.preparar(quiet=True) else "Pronto (com alertas)"
        self._em_thread(f)

    def clique(self):
        def f():
            if self._status():                                    # gravando → parar
                self.msg = "Salvando…"; gd.gravar(quiet=True); self.gravando = False; self.msg = "Salvo. Pronto"
            else:
                ok, m, _ = licenca.verificar()
                if not ok:
                    self.msg = "Versão expirada"; gd.dialog("Gravar Doc — Licença", f"{m}\n\nID desta máquina:\n{licenca.id_maquina()}", ok=False); return
                if not gd.pronto():
                    self.msg = "Preparando… (~30 s)"
                    if not gd.preparar(quiet=True): self.msg = "Pronto (com alertas)"; return
                self.msg = "Iniciando…"; gd.gravar(quiet=True); self.gravando = self._status()
                if not self.gravando: self.msg = "Falhou — veja o OBS"
        self._em_thread(f)

    def abrir_pasta(self):
        try: os.startfile(str(gd.rec_path()))
        except Exception as e: gd.log(f"pasta: {e!r}")

    # ------------------------------------------------------------ estado do OBS (thread)
    def _status(self):
        try:
            if self._ws is None:
                import obsws_python as obs
                self._ws = obs.ReqClient(host="localhost", port=gd.CFG.get("ws_port", 4455), password="", timeout=2)
            return bool(self._ws.get_record_status().output_active)
        except Exception:
            self._ws = None
            return False

    def _vigiar(self):
        while True:
            if not self.ocupado:
                self.gravando = self._status()
            time.sleep(1)

    def run(self): self.root.mainloop()

if __name__ == "__main__":
    Painel().run()
